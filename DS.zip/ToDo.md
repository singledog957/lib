# *Think Before You Do*

>别刷题了，先把算法整明白
>先动脑
>把完成时间、debug时间记下来
 
>把题目看清楚！
## Monument
>`FuckU.c` (build for 1h,debug for 7h,**not pass**)
>`tmp.c`(build for 1.5h,debug for 7h,**not pass**)
>`flightStimulate.c`(build for 3h,**题目看错，层序没看**)

## Coding

### DS

- [x] 中序线索，前序、后序遍历
- [x] 邻接矩阵存储图
- [x] 邻接表存图
- [x] Kruskal最小生成树
- [x] Prim最小生成树

### Algorithm

- [ ] 动态规划-最长子序列+二分查找
- [ ] 0/1背包问题
- [ ] 区间dp
- [ ] 贪心算法
- [x] 哈希表
- [x] UTHash
- [x] KMP匹配

## Web

- [x] **warp解锁GPT**
- [x] Nginx反向代理
- [x] Python升级
- [ ] Java
- [x] GPT API调用
- [ ] 动态网页(vue) `low priority`

## Interests

- [x] Latex
- [ ] Python
- [ ]  lol
