#include <stdio.h>
#include <stdlib.h>

// ͷ�巨��ͷ�ڵ�Ϊ��
typedef struct _node
{
    int val;
    struct _node *next;
} node;
void enList(node *head, int val, int key) // ���뵽key��
{
    node *now = head;
    while (now->next != NULL && now->val != key)
        now = now->next;
    if (now->next == NULL)
    {
        now->next = calloc(1, sizeof(node));
        now = now->next;
        now->val = val;
    }
    else
    {
        node *tmp = now->next;
        now->next = calloc(1, sizeof(node));
        now->next->val = val;
        now->next->next = tmp;
    }
}
/*
 * @brief �������в���key��������key���ڽڵ��ָ��
 * @param ����ͷ��������ֵ
 */
node *checkList(node *head, int key)
{
    node *now = head;
    while (now->next != NULL && now->val != key)
        now = now->next;
    return now;
}
void delList(node *head, int key) // ɾ��key->next
{
    node *res = checkList(head, key);
    if (res != NULL)
    {
        node *tmp = res->next;
        res->next = res->next->next;
        free(tmp);
    }
}
int main()
{
    int q;
    scanf("%d", &q);
    node *head = calloc(1, sizeof(node));
    head->next = calloc(1, sizeof(node));
    head->next->val = 1;
    for (int i = 0; i < q; i++)
    {
        int s;
        scanf("%d", &s);
        switch (s)
        {
            int x, y;
        case 1:
            scanf("%d %d", &x, &y);
            enList(head, y, x);
            break;
        case 2:
            scanf("%d", &x);
            node *res = checkList(head, x);
            if (res->next == NULL)
                printf("0\n");
            else
                printf("%d\n", res->next->val);
            break;
        case 3:
            scanf("%d", &x);
            delList(head, x);
            break;
        }
    }
    return 0;
}