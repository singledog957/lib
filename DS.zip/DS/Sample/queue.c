// start:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
// FILE *out;
#define P 1000003
#define INF 0x7777777f

typedef struct _node
{
    int val;
    struct _node *next;
} node;

node *initialSeq()
{
    node *tmp = calloc(1, sizeof(node));
    (tmp)->val = INF;
    return tmp;
}

void pushSeq(node **front, node **rear, int key)
{
    if (*front == NULL)
    {
        *front = initialSeq();
        *rear = *front;
    }
    node *new = calloc(1, sizeof(node));
    new->val = key;
    (*rear)->next = new;
    *rear = new;
    if ((*front) != NULL && (*front)->val == INF)
        *front = (*front)->next;
}

node *popSeq(node **front) // ����
{
    if (*front == NULL)
    {
        printf("ERR_CANNOT_POP\n");
        return NULL;
    }
    node *res = *front;
    *front = (*front)->next;
    return res;
}

node *querySeq(node **front) // ��ѯ����Ԫ��
{
    if (*front == NULL)
    {
        printf("ERR_CANNOT_QUERY\n");
        return NULL;
    }
    else
        printf("%d\n", (*front)->val);
    return *front;
}

int countSeq(node **head, node **rear)
{
    node *tmp = *head;
    int cnt = 0;
    while (tmp != *rear && tmp != NULL)
    {
        tmp = tmp->next;
        cnt++;
    }
    if (tmp == NULL)
        return 0;
    return cnt + 1;
}

int main()
{
    int n;
    scanf("%d", &n);
    // out = fopen("out.txt", "w");
    node *front = NULL;
    node *rear = front;
    for (int i = 0; i < n; i++)
    {
        int x;
        scanf("%d", &x);
        switch (x)
        {
            int p;
        case 1:
            scanf("%d", &p);
            pushSeq(&front, &rear, p);
            break;
        case 2:
            popSeq(&front);
            break;
        case 3:
            querySeq(&front);
            break;
        case 4:
            printf("%d\n", countSeq(&front, &rear));
            break;
        }
    }
    // fclose(out);
    return 0;
}