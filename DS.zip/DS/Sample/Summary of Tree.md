﻿# 1. 二叉树的定义和基本操作

```c
// 二叉树节点的定义
typedef struct TreeNode{
    char* data; 
    struct TreeNode *left, *right;
    int level;
}TreeNode;

// 创建一个节点
TreeNode* CreateNode(char* data, int level){
    TreeNode* newnode = malloc(sizeof(TreeNode));
    strcpy(newnode->data, data);
    newnode->level = level;
    newnode->left = newnode->right = NULL;
    return newnode;
}

// 查找节点
TreeNode* search(TreeNode* node, char* key){
    if(node == NULL)    return NULL;
    if(strcmp(node->data, key) == 0)     return node;
    TreeNode* res = search(node->left, key);
    if(res)    return res;
    else return search(node->right, key);
}
```

>输入：<父节点数据> <左孩子数据> <右孩子数据>(没有孩子则为NULL, 中间以空格分隔),该如何创建节点?

代码如下：

```c
char parentName[21], lChildName[21], rChildName[21];
scanf("%s %s %s", parentName, lChildName, rChildName);
// 找到父节点
TreeNode* parent = search(T, parentName);
// 创建孩子节点并建立父子关系
if(strcmp(lChildName, "NULL")){
    parent->left = CreateNode(lChildName, parent->level+1);
}
if(strcmp(rChildName, "NULL")){
    parent->right = CreateNode(rChildName, parent->level+1);
}
```

>如何求一棵二叉树的深度？

代码如下：

```c
int TreeDepth(TreeNode* root) {
    if(root == NULL)    return 0;
    // max(x, y) 应该以函数的方式实现，不能用宏定义
    return max(TreeDepth(root->left), TreeDepth(root->right)) + 1;
}
```

# 2. 二叉树的算法问题

### (1) 到值为key的节点的所有路径

输入为待查找二叉树的根节点root和待查找的节点数据域key值，返回从root出发到所有值为key的节点的路径

代码如下：

```c
#define MAXN 100

// 全局变量
TreeNode path[MAXN];
int pathSize;
TreeNode ans[100][MAXN];   // ans[i]表示一条道路
int ansColSize[100];       // ansColSize[i]表示道路的大小
int ansSize;

void findPaths(TreeNode* root, char* key) {
    if (strcmp(root->data, key) == 0) {
        path[pathSize++] = *root;
        // 根据实际需要，如果只要直接输出的话就打印出来即可，需要排序的话就存在数组里
        memcpy(ans[ansSize], path, sizeof(TreeNode) * pathSize);
        ansColSize[ansSize] = pathSize;
        ansSize++;
        return;
    }
    path[pathSize++] = *root;
    if (root->left) {
        findPaths(root->left, key);
        pathSize--;
    }
    if (root->right) {
        findPaths(root->right, key);
        pathSize--;
    }
}
```

### (2) 最近公共祖先
>
>最近公共祖先的定义为：对于有根树 $T$ 的两个节点 $p$、$q$，最近公共祖先表示为一个节点 $x$，满足 $x$ 是 $p$、$q$ 的祖先且 $x$ 的深度尽可能大(一个节点也可以是它自己的祖先)

![在这里插入图片描述](https://img-blog.csdnimg.cn/86c5aa4d675d4bbfbb201c0239758292.png)

下面的代码输入为树的根节点$root$, 需要寻找最近公共祖先的两个节点 $p$ 和 $q$, 返回值它们在树中的最近公共祖先节点

```c
TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q) {
    if(root == NULL || root == p || root == q)     return root;
    
    TreeNode* lChild = lowestCommonAncestor(root->left, p, q);
    TreeNode* rChild = lowestCommonAncestor(root->right, p, q);
    if (lChild && rChild)     return root;
    else if (lChild)    return lChild;
    else if (rChild)    return rChild;
    return NULL;
}
```

在求解两个节点$u$和$v$的最近公共祖先的基础上，还可以得到这两个节点之间的最短路径$\delta(u,v)$。
记节点$u$和$v$的最近公共祖先为$p$，从节点$p$出发，分别进行深度优先搜索，调用search()方法得到从节点$p$到节点$u$和$v$的路径 $path_{1}$ 和 $path_{2}$，然后将两条路径合并即可。

### (3) 树的直径
>
>我们将一棵树$T=(V,E)$的**直径**定义为$\max\limits_{u,v\in V}\delta(u,v)$，也就是说，将树视作一个无向图，图中所有最短路径距离的最大值即为树的直径。

![在这里插入图片描述](https://img-blog.csdnimg.cn/dfd18064df904ad1bf933ed00fcceb97.png)
实现思路：
一条路径的长度为该路径经过的节点数减一，所以求直径（即求路径长度的最大值）等效于求路径经过节点数的最大值减一。而任意一条路径均可以被看作由某个节点为起点，从其左儿子和右儿子向下遍历的路径拼接得到。
假设我们知道对于该节点的左儿子向下遍历经过最多的节点数$L$和右儿子向下遍历经过最多的节点数$R$，那么通过该节点的路径经过的节点数的最大值即为$L+R+1$。

代码如下：

```c
// global
int d;

int dfs(TreeNode* root){
    if(root == NULL)   return 0;
    int l = dfs(root->left);
    int r = dfs(root->right);
    d = max(d, l + r + 1);
    return max(l, r) + 1;
}

int diameterOfBinaryTree(TreeNode* root){
    d = 0;
    dfs(root);
    return d - 1;
}
```

自然地，该算法可以推广到N叉树，对于一棵N叉树的某个节点，对以它的所有子孩子为根的子树向下遍历得到高度$h_{i}$，取最大的两棵子树高度$h_{1}$ 和$h_{2}$，那么经过该节点的路径最多经过的节点数为$h_{1}+h_{2}+1$。

# 3. N叉树的定义和基本操作

```c
#define MAXN 10   

// N叉树节点的定义
typedef struct TreeNode{
    char* data;
    int childrenNum;
    struct TreeNode* children[MAXN];
    int level;
}TreeNode;

// 创建节点
TreeNode* CreateNode(char* data, int level){
    TreeNode* newnode = malloc(sizeof(TreeNode));
    strcpy(newnode->data, data);
    newnode->level = level;
    newnode->childrenNum = 0;
    memset(newnode->children, 0, sizeof(children));
    return newnode;
}

// 查找节点
TreeNode* search(TreeNode* node, char* key){
    if (strcmp(node->data, key) == 0)   return node;
 TreeNode* res = NULL;
 for (int i = 0; i < node->childNum; i++) {
  res = search(node->children[i], key);
  if (res)   return res;
 }
 return res;
}

// 层序遍历
void levelOrder(TreeNode* root){
    TreeNode* q[100];
    int head = 0, tail = 0;
    q[tail++] = root;
    Visit(root);
    while(head < tail){
        TreeNode* node = q[head++];
        for(int i = 0; i < node->childrenNum; i++){
            q[tail++] = node->children[i];
            Visit(node->children[i]);
        }
    }
}
```

>输入：<父节点数据> <孩子节点数据>(中间以空格分隔), 该如何创建节点?

代码如下:

```c
char parentName[21], childName[21];
scanf("%s %s", parentName, childName);
// 找到父节点
TreeNode* parent = search(T, parentName);
// 创建孩子节点
TreeNode* child = CreateNode(childName, parent->level+1);
// 建立父子关系
parent->children[(parent->childrenNum)++] = child;
```

> 如何求一棵N叉树的深度
>
代码如下：

```c
int TreeDepth(TreeNode* root) { 
    if(root == NULL)    return 0;
    int childDepth = 0;
    for(int i = 0; i < root->childrenNum; i++) {
        // max(x, y) 应该以函数的方式实现，不能用宏定义
        childDepth = max(childDepth, TreeDepth(root->children[i]));
    }
    return childDepth + 1;
}
```
