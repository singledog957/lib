typedef struct node
{
    int val;
    // bool used;
    struct node *s[3];
} node;
node *root, *searchResult;
node *trees[500] = {0};
int itrees = 0;

typedef struct gate
{
    int num;
    int traffic;
} gate;
typedef struct seq
{
    node *val;
    struct seq *next;
} seq;
seq *front, *rear;
gate gates[100] = {{0}};
/*void searchTree(int val, node *now)
{
    if (serachFlag == 1 || now == NULL)
        return;
    else if (now->val == val)
    {
        searchResult = now;
        serachFlag = 1;
        return;
    }
    for (int i = 0; i < 3; i++)
    {
        searchTree(val, now->s[i]);
        if (serachFlag == 1)
            return;
    }
}
void createTree(int r)
{
    searchTree(r, root);
    serachFlag = 0;
    node *cur = searchResult;
    int n = 0;
    for (int i = 0; i < 3 && n != -1; i++)
    {
        scanf("%d", &n);
        if (n == -1)
            return;
        node *tmp = (node *)calloc(1, sizeof(node));
        tmp->val = n;
        cur->s[i] = tmp;
    }
    scanf("%d", &n);
    return;
}*/
seq *initialSeq()
{
    seq *tmp = (seq *)calloc(1, sizeof(seq));
    return tmp;
}
void enterSeq(node *cur)
{
    if (rear == NULL)
    {
        front = (seq *)calloc(1, sizeof(seq));
        rear = front;
        rear->val = cur;
        front->val = cur;
        return;
    }
    seq *tmp = (seq *)calloc(1, sizeof(seq));
    rear->next = tmp;
    tmp->val = cur;
    rear = tmp;
    if (front == NULL)
        front = rear;
}
seq *popSeq()
{
    seq *tmp = (front);
    (front) = (front)->next;
    if ((front) == rear && front->val == NULL)
    {
        rear = front = NULL;
    }
    return tmp;
}
void travelTree(node *cur)
{
    int icur = 0;
    if (cur == NULL)
        return;
    for (int j = 0; j < cnt + igate; j++) // �ӿ�ʱ����
    {
        seq *tmp = popSeq();
        trees[itrees++] = tmp->val;
        cur = trees[icur++];
        for (int i = 0; i < 3; i++) // 3Ϊ��
        {
            if (cur->s[i] != NULL)
                enterSeq(cur->s[i]);
        }
    }
    return;
}