#define hash(a) a - 'a'
typedef struct trie
{
    struct trie *words[26];
    bool isEnd;
} trie;

trie *trieCreate()
{
    trie *root = (trie *)calloc(1, sizeof(trie));
    return root;
}

void trieInsert(trie *obj, char *word)
{
    int i = 0;
    trie *now = obj;
    while (word[i] != 0)
    {
        if (now->words[hash(word[i])] == NULL)
        {
            trie *tmp = (trie *)calloc(1, sizeof(trie));
            now->words[hash(word[i])] = tmp;
            now = tmp;
        }
        else
            now = now->words[hash(word[i])];
        i++;
    }
    now->isEnd = 1;
}

bool trieSearch(trie *obj, char *word)
{
    trie *now = obj;
    int i = 0;
    while (word[i] != 0)
    {
        if (now->words[hash(word[i])] == NULL)
            return false;
        now = now->words[hash(word[i])];
        i++;
    }
    if (now->isEnd)
        return true;
    return false;
}

bool trieStartsWith(trie *obj, char *prefix)
{
    trie *now = obj;
    int i = 0;
    while (prefix[i] != 0)
    {
        if (now->words[hash(prefix[i])] == NULL)
            return false;
        now = now->words[hash(prefix[i])];
        i++;
    }
    return true;
}

void trieFree(trie *obj)
{
    if (obj == NULL)
        return;
    for (int i = 0; i < 26; i++)
        trieFree(obj->words[i]);
    free(obj);
}
