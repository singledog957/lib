

// start:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
FILE *out;
#define INF 0x777777f
typedef struct stack
{
    /* data */
    int val;
    struct stack *next;
} stack;
stack *initialStack()
{
    stack *top = (stack *)calloc(1, sizeof(stack));
    top->val = INF;
    return top;
}
stack *popStack(stack **top) // ��ջ�����س�ջԪ��
{
    stack *cur = *top;
    if (cur->val != INF)
        *top = (*top)->next;
    else
        printf("Empty\n");
    return cur;
}
void enterStack(int key, stack **top) // ��ջ
{
    stack *tmp = (stack *)calloc(1, sizeof(stack));
    (tmp)->next = *top;
    (*top) = tmp;
    (*top)->val = key;
}
void freeStack(stack *top)
{
    stack *tmp = top;
    while (top != NULL)
    {
        tmp = top;
        top = top->next;
        free(tmp);
    }
}
void queryStack(stack **top) // �õ�ջ��Ԫ��
{
    if ((*top)->val == INF)
        printf("Anguei!\n");
    else
        printf("%d\n", (*top)->val);
}
int countStack(stack **top) // �õ�ջ��Ԫ�ظ���
{
    stack *now = *top;
    int cnt = 0;
    while (now != NULL)
    {
        now = now->next;
        cnt++;
    }
    return cnt - 1;
}
int main()
{
    int T;
    scanf("%d", &T);
    for (int i = 0; i < T; i++)
    {
        stack *top = initialStack();
        int x;
        scanf("%d", &x);
        for (int j = 0; j < x; j++)
        {
            char s[6];
            scanf("%s", s);
            int n;
            switch (s[2])
            {
            case 's': // push
                scanf("%d", &n);
                enterStack(n, &top);
                break;
            case 'p': // pop
                popStack(&top);
                break;
            case 'e': // query
                queryStack(&top);
                break;
            case 'z': // size
                printf("%d\n", countStack(&top));
                break;
            }
        }
    }
    return 0;
}