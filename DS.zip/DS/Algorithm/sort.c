#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int times;
void swap(int *a, int *b)
{
    int tmp = *a;
    *a = *b;
    *b = tmp;
}
void selectSort(int *nums, int inums)
{
    int min = 0;
    int flag = 0;
    for (int i = 0; i < inums; i++)
    {
        for (int j = i + 1; j < inums; j++)
        {
            min = nums[min] < nums[j] ? min : j;
            times++;
        }
        swap(&(nums[min]), &(nums[i]));
    }
}
void bubbleSort(int *nums, int inums)
{
    int flag = 1;
    int j = 1;
    while (flag)
    {
        flag = 0;
        for (int i = 0; i < inums - j; i++)
        {
            times++;
            if (nums[i] > nums[i + 1])
            {
                swap(&nums[i], &nums[i + 1]);
                flag = 1;
            }
        }
        j++;
    }
}
// 递归版本
/*void MaxHeapify(int *nums, int inums, int root)
{
    int left = root * 2 + 1, right = root * 2 + 2;
    int max = root;
    times++;
    if (right < inums && nums[right] > nums[max])
        max = right;
    if (left < inums && nums[left] > nums[max])
        max = left;
    if (max != root)
    {
        swap(&nums[max], &nums[root]);
        MaxHeapify(nums, inums, max);
    }
}
void heapSort(int *nums, int inums)
{
    for (int i = inums / 2 - 1; i >= 0; i--)
        MaxHeapify(nums, inums, i);
    for (int i = inums - 1; i > 0; i--)
    {
        swap(&nums[i], &nums[0]);
        MaxHeapify(nums, inums, 0);
    }
    return;
}*/
void adjust(int k[], int i, int n)
{
    int j, temp;
    temp = k[i];
    j = 2 * i + 1;
    while (j < n)
    {
        if (j < n - 1 && k[j] < k[j + 1])
            j++;
        times++;
        if (temp >= k[j])
            break;
        k[(j - 1) / 2] = k[j];
        j = 2 * j + 1;
    }
    k[(j - 1) / 2] = temp;
}
void heapSort(int *nums, int inums)
{
    for (int i = inums / 2 - 1; i >= 0; i--)
        adjust(nums, i, inums);
    // adjust(nums, 0, inums);
    for (int i = inums - 1; i > 0; i--)
    {
        swap(&nums[i], &nums[0]);
        adjust(nums, 0, i);
    }
}
void merge(int *nums, int left, int right)
{
    int mid = (left + right) / 2;
    if (left > mid)
        return;
    int i = left, j = mid + 1;
    int ians = 0;
    int *ans = (int *)calloc(right - left + 1, sizeof(int));
    while (i <= mid && j <= right)
    {
        times++;
        if (nums[i] > nums[j])
            ans[ians++] = nums[j++];
        else
            ans[ians++] = nums[i++];
    }
    while (i <= mid)
        ans[ians++] = nums[i++];
    while (j <= right)
        ans[ians++] = nums[j++];
    memcpy(nums + left, ans, sizeof(int) * (right - left + 1));
    free(ans);
}
void mergeSort(int *nums, int low, int high)
{
    if (low < high)
    {
        mergeSort(nums, low, (high + low) / 2);
        mergeSort(nums, (high + low) / 2 + 1, high);
        merge(nums, low, high);
    }
}
int partion(int *nums, int left, int right)
{
    int i = left + 1, pivot;
    if (left < right)
    {
        pivot = nums[left];
        for (int j = left + 1; j < right + 1; j++)
        {
            // times++;
            if (nums[j] < pivot)
            {
                swap(&nums[i], &nums[j]);
                i++;
            }
        }
        swap(&nums[i - 1], &nums[left]);
    }
    return i - 1;
}
void quickSort(int *nums, int low, int high)
{
    if (low < high)
    {
        int mid = partion(nums, low, high);
        quickSort(nums, low, mid - 1);
        quickSort(nums, mid + 1, high);
    }
}
/*void quickSort(int k[], int left, int right)

{
    int i, last;
    if (left < right)
    {
        last = left;
        for (i = left + 1; i <= right; i++)
        {
            times++;
            if (k[i] < k[left])
                swap(&k[++last], &k[i]);
        }
        swap(&k[left], &k[last]);
        quickSort(k, left, last - 1);
        quickSort(k, last + 1, right);
    }
}*/
// 元素个数，操作符
// 元素
int main()
{
    int inums, x;
    int *nums;
    scanf("%d %d", &inums, &x);
    nums = (int *)calloc(inums, sizeof(int));
    for (int i = 0; i < inums; i++)
        scanf("%d", &(nums[i]));
    switch (x)
    {
    case 1:
        selectSort(nums, inums);
        break;
    case 2:
        bubbleSort(nums, inums);
        break;
    case 3:
        heapSort(nums, inums);
        break;
    case 4:
        mergeSort(nums, 0, inums - 1);
        break;
    case 5:
        quickSort(nums, 0, inums - 1);
        break;
    default:
        break;
    }
    for (int i = 0; i < inums - 1; i++)
        printf("%d ", nums[i]);
    printf("%d\n%d", nums[inums - 1], times);
    return 0;
}