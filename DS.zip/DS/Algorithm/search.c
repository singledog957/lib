#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define NHASH 3001
#define MULT 37
#define WORDSSIZE 50
typedef struct word
{
    char *s;
    struct word *next;
} word;
word words[3001];
int times;
char **dictionary;
int idic;
unsigned int hash(char *str)
{
    unsigned int h = 0;
    char *p;
    for (p = str; *p != '\0'; p++)
        h = MULT * h + *p;
    return h % NHASH;
}
int lineSearch(char *key)
{
    int i = 0;
    while (strcmp(key, dictionary[i]) > 0 && i < idic)
        i++;
    times = i + 1;
    if (strcmp(key, dictionary[i]) == 0)
        return 1;
    return 0;
}
int binSearch(char *key, int start, int end)
{
    int low = start, high = end;
    int mid = (low + high) / 2;
    while (low <= high)
    {
        int res = strcmp(key, dictionary[mid]);
        times++;
        if (res < 0)
            high = mid - 1;
        else if (res > 0)
            low = mid + 1;
        else
            return 1;
        mid = (high + low) / 2;
    }
    return 0;
}
int indexSearch(char *key)
{
    int index[26][2];
    int i = 0;
    int loc = 0;
    index[0][0] = 0;
    while (i < 26)
    {
        while (dictionary[loc][0] == 'a' + i && loc < idic)
            loc++;
        index[i][1] = loc;
        i++;
        index[i][0] = index[i - 1][1];
    }
    i = 0;
    binSearch(key, index[key[0] - 'a'][0], index[key[0] - 'a'][1] - 1);
}
int hashSearch(char *key)
{
    int index = hash(key);
    word *now = &(words[index]);
    char *str = now->s;
    while (now->next != NULL && strcmp(key, str) != 0)
    {
        now = now->next;
        str = now->s;
        times++;
    }
    times++;
    if (strcmp(key, str) == 0)
        return 1;
    return 0;
}
void enHash()
{
    for (int i = 0; i < idic; i++)
    {
        int index = hash(dictionary[i]);
        word *now = &(words[index]);
        if (now->s != NULL && (now->s)[0] != 0)
        {
            while (now->next != NULL)
                now = now->next;
            word *tmp = (word *)calloc(1, sizeof(word));
            now->next = tmp;
            tmp->s = dictionary[i];
        }
        else
            words[index].s = dictionary[i];
    }
}
int main()
{
    FILE *in = fopen("dictionary3000.txt", "r");
    dictionary = (char **)calloc(3500, sizeof(char *));
    dictionary[idic] = (char *)calloc(WORDSSIZE, sizeof(char));
    while (fscanf(in, "%s", dictionary[idic]) != EOF)
        dictionary[++idic] = (char *)calloc(WORDSSIZE, sizeof(char));
    char key[40] = {0};
    int n, ans;
    enHash();
    while (scanf("%s%d", key, &n) != EOF)
    {
        switch (n)
        {
        case 1:
            ans = lineSearch(key);
            printf("%d %d\n", ans, times);
            break;
        case 2:
            ans = binSearch(key, 0, idic - 1);
            printf("%d %d\n", ans, times);
            break;
        case 3:
            ans = indexSearch(key);
            printf("%d %d\n", ans, times);
            break;
        case 4:
            ans = hashSearch(key);
            printf("%d %d\n", ans, times);
            break;
        }
        times = 0;
    }
    fclose(in);
    for (int i = 0; i < idic; i++)
        free(dictionary[i]);
    free(dictionary);
    return 0;
}