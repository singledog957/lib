int *getNext(char *needle, int n)
{
    int *next = (int *)calloc(n, sizeof(int));
    next[0] = 0;
    int i = 1, j = 0;
    while (i < n)
    {
        while (i < n && needle[i] == needle[j])
        {
            next[i++] = ++j;
        }
        if (j == 0)
        {
            i++;
            continue;
        }
        j = next[j - 1];
    }
    return next;
}
/*int *getNext(char *p)
{
    int *next = (int *)calloc(strlen(p), sizeof(int));
    next[0] = -1;
    int i = 0, j = -1;
    while (i < (int)strlen(p))
    {
        if (j == -1 || p[i] == p[j])
        {
            ++i;
            ++j;
            next[i] = j;
        }
        else
            j = next[j];
    }
    return next;
}*/
int strStr(char *haystack, char *needle)
{
    int *next = getNext(needle, strlen(needle));
    int hlen = strlen(haystack), nlen = strlen(needle);
    int i = 0, j = 0;
    while (i < hlen)
    {
        while (i < hlen && haystack[i] == needle[j])
        {
            i++, j++;
        }
        if (j == nlen)
            return (i - j);
        j = j > 0 ? next[j - 1] : 0;
        if (j == 0 && haystack[i] != needle[j])
            i++;
    }
    return -1;
}