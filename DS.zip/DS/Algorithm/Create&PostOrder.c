#include <stdio.h>
#include <malloc.h>
typedef struct tree
{
    char val;
    struct tree *ll;
    struct tree *rr;
} tree;
typedef struct seq
{
    tree *d[30];
    int front;
    int rear;
} seq;
tree *enter(char, int, tree *);
tree *travel(tree *);
int main()
{
    int n, cnt = 0;
    scanf("%d", &n);
    seq *s = (seq *)malloc(sizeof(seq));
    s->front = 0, s->rear = 1;
    tree *root;
    char x;
    while (scanf(" %c", &x) != EOF)
    {
        char y, z;
        int i = 0;
        if (!cnt)
        {
            root = (tree *)malloc(sizeof(tree));
            s->d[0] = root;
            root->val = x;
            cnt++;
        }
        else
        {
            for (i = 0; i < s->rear; i++)
                if (s->d[i]->val == x)
                    break;
        } // s->d[i] is root
        scanf("%c%c", &y, &z);
        if (y != '*')
        {
            s->d[s->rear++] = enter(y, 1, s->d[i]);
            cnt++;
        }
        if (z != '*')
        {
            s->d[s->rear++] = enter(z, 0, s->d[i]);
            cnt++;
        }
        if (y != '*' && x != '*')
            s->front++;
    }
    travel(root);
    return 0;
}
tree *enter(char x, int i, tree *f)
{
    tree *s = (tree *)malloc(sizeof(tree));
    s->ll = s->rr = NULL;
    s->val = x;
    if (i)
        f->ll = s;
    else
        f->rr = s;
    return s;
}
tree *travel(tree *root)
{
    if (!root)
        return NULL;
    printf("%c", root->val);
    if (root->ll)
        travel(root->ll);
    if (root->rr)
        travel(root->rr);
}