#include <stdio.h>
#include <stdlib.h>
#include <uthash.h>
typedef struct _test
{
    int id;
    UT_hash_handle hh;
} test;
test *table = NULL;
int cmp(const void *x,const void* y)
{
    return ((test *)x)->id - ((test *)y)->id;
}
int main()
{
    test *user = calloc(1, sizeof(test));
    user->id = 20;
    HASH_ADD_INT(table, id, user);
    test *now = malloc(sizeof(test));
    now->id = 2;
    HASH_ADD_INT(table, id, now);
    int tmp = 20;
    test *res;
    HASH_FIND_INT(table, &tmp, res);
    printf("%d %p\n", res->id, res);
    tmp = 2;
    HASH_FIND_INT(table, &tmp, res);
    HASH_SORT(table, cmp);
    printf("%d %p", res->id, res);
    HASH_DEL(table, now);
    HASH_CLEAR(hh, table);
    return 0;
}