#include <stdio.h>
#include <stdlib.h>
#define p 1000003
#define hash(a) a % p
typedef struct num
{
    long long val;
    int times;
} num;
num *Code, *nums;
int searchHash(int key)
{
    int index = hash(key);
    while (Code[index].val != key && Code[index].val)
        index++;
    return Code[index].val == 0 ? -1 : index;
}
int createHash(int val)
{
    int index = hash(val);
    while (Code[index].val != 0 && Code[index].val != val)
        index++;
    if (Code[index].val == 0)
        Code[index].val = val;
    else
        Code[index].times++;
}
int main()
{
    int n, c, tmp;
    // FILE *in;
    // in = fopen("P1102_3.in", "r");
    scanf("%d%d", &n, &c);
    Code = (num *)calloc(p, sizeof(num));
    nums = (num *)calloc(n, sizeof(num));
    for (int i = 0; i < n; i++) // while (fscanf(in, "%d", &tmp) != EOF)
    {
        scanf("%d", &tmp);
        createHash(tmp);
        nums[i].val = tmp;
    }
    int index = 0;
    long long ans = 0;
    for (int i = 0; i < n; i++)
    {
        index = searchHash(nums[i].val + c);
        if (index != -1)
        {
            ans = ans + 1 + Code[index].times;
        }
    }
    printf("%lld", ans);
    // fclose(in);
    free(Code), free(nums);
    return 0;
}