#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#define P 1000003
#define base 233

char *code[P];
int hash(char *s)
{
    int i = 0;
    int val = 0;
    while (s[i] != 0)
    {
        val = val * base % P + s[i] % P;
        i++;
    }
    return val;
}
bool hashSearch(char *s)
{
    int key = hash(s);
    while (code[key] != NULL && strcmp(code[key], s) != 0)
        key++;
    if (code[key] == NULL)
    {
        code[key] = s;
        return 0;
    }
    return 1;
}
int main()
{
    int x;
    scanf("%d", &x);
    char **str = calloc(x, sizeof(char *));
    int cnt = 0;
    for (int i = 0; i < x; i++)
    {
        str[i] = calloc(10001, sizeof(char));
        scanf("%s", str[i]);
        cnt += hashSearch(str[i]);
    }
    printf("%d", x - cnt);
    return 0;
}
