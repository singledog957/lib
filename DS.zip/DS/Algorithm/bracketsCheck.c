#include <stdio.h>
#include <malloc.h>
int main()
{
    typedef struct Check
    {
        char val;
        struct Check *next;
    } ch;
    ch *cur = (ch *)malloc(sizeof(ch));
    ch *head = (ch *)malloc(sizeof(ch));
    head->next = NULL;
    ch *rear = head;
    cur->val = 0;
    while (cur->val != '@')
    {
        scanf("%c", &(cur->val));
        if (cur->val == '(')
        {
            ch *q = (ch *)malloc(sizeof(ch));
            q->val = cur->val;
            rear->next = q;
            rear = q;
            q->next = NULL;
        }
        else if (cur->val == ')')
        {
            if (!(head->next))
            {
                printf("NO");
                return 0;
            }
            ch *p = head->next;
            head->next = p->next;
            free(p);
            if (!(head->next))
                rear = head;
        }
    }
    if (!(head->next))
    {
        printf("YES");
        return 0;
    }
    else
    {
        printf("NO");
        return 0;
    }
}