// start:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <uthash.h>
#include <stdbool.h>

#define P 1000003
#define INF 0x7777777f
#define SIZEPERLINE 500;

typedef struct _data
{
    bool type;
    char name[21];
    char time[13];
    int id;
} Data;

typedef struct TreeNode
{
    Data data;
    struct TreeNode *children[100];
    int childrenNum;
    UT_hash_handle hh;
} TreeNode;

typedef struct _file
{
    char path[100];
    char time[25];
} File;

TreeNode *head;
TreeNode trees[1000];
int itree = 0;
TreeNode *table = NULL;
File files[1000];
int ifiles;

// ����һ���ڵ�
TreeNode *CreateNode(Data *data)
{
    TreeNode *newnode = calloc(1, sizeof(TreeNode));
    memcpy(&newnode->data, data, sizeof(Data));
    return newnode;
}

// ���ҽڵ�
TreeNode *search(TreeNode *node, char *key)
{
    if (node == NULL)
        return NULL;
    if (strcmp(node->data.name, key) == 0)
        return node;
    TreeNode *res = NULL;
    for (int i = 0; i < node->childrenNum; i++)
    {
        res = search(node->children[i], key);
        if (res != NULL)
            return res;
    }
    return res;
}

void levelOrder(TreeNode *root)
{
    TreeNode *q[100];
    int head = 0, tail = 0;
    q[tail++] = root;
    Visit(root);
    while (head < tail)
    {
        TreeNode *node = q[head++];
        for (int i = 0; i < node->childrenNum; i++)
        {
            q[tail++] = node->children[i];
            Visit(node->children[i]);
        }
    }
}

char *getNum(char *s)
{
    char *nums = calloc(5, sizeof(char));
    int j = 0;
    if (s == '(' || s == ',')
        s++;
    for (int i = 0; s[i] != 0; i++)
    {
        if (isdigit(s[i]))
            nums[j++] = s[i];
    }
    nums[j] = 0;
    return nums;
}

void createTree(TreeNode *cur, char *route)
{
    TreeNode *res = NULL;
    char *now = route;
    while ((*now) != 0)
    {
        char *nums = getNum(now);
        int len = strlen(nums);
        now += len;
        int id = strtol(nums, NULL, 10);
        TreeNode *res = NULL;
        HASH_FIND_INT(table, &id, res);
        if (res->data.type)
            createTree(res, now);
        else
            cur->children[cur->childrenNum++] = res;
    }
}

void copy(File *now)
{
    int m
}

int main()
{
    FILE *in = fopen("in.txt", "r");
    char route[5001];
    fscanf(in, "%s", route);
    Data new;
    while (fscanf(in, "%d %s %d %s", new.id, new.name, new.type, new.time) != EOF)
    {
        memcpy(&trees[itree++].data, &new, sizeof(Data));
        HASH_ADD_INT(table, data.id, &trees[itree - 1]);
    }
    createTree(head, route);
    scanf("%d", &ifiles);
    for (int i = 0; i < ifiles; i++)
    {
        scanf("%s %s", files[i].path, files[i].time);
        copy(files);
    }
}