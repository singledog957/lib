#include <stdio.h>
#include <stdlib.h>
int cmp(const void *, const void *);
typedef struct num
{
    long long coe;
    long long index;
} num;
int toNum(char *, num *);
int main()
{
    char s1[9000] = {0}, s2[9000] = {0};
    gets(s1), gets(s2);
    num a1[9000] = {{0}}, a2[9000] = {{0}}, ans[9000] = {{0}};
    int l1 = toNum(s1, a1), l2 = toNum(s2, a2);
    int m = 0;
    for (int i = 0; i < l1; i++)
    {
        for (int j = 0; j < l2; j++)
        {
            ans[m].coe = a1[i].coe * a2[j].coe;
            ans[m++].index = a1[i].index + a2[j].index;
        }
    }
    qsort(ans, m, sizeof(num), cmp);
    for (int i = 0; i < m; i++)
    {
        if (ans[i].index == ans[i + 1].index)
        {
            int j = i;
            while (ans[i].index == ans[i + 1].index && i < m)
            {
                ans[j].coe += ans[i + 1].coe;
                ans[++i].coe = 0;
                m--;
            }
        }
    }
    for (int i = 0; i < m; i++)
    {
        if (ans[i].coe)
            printf("%lld %lld ", ans[i].coe, ans[i].index);
    }
    return 0;
}
int toNum(char *s, num *a)
{
    int i = 0, j = 0;
    while (s[i] != 0)
    {
        while (s[i] != ' ')
        {
            a[j].coe = a[j].coe * 10 + s[i] - '0';
            i++;
        }
        i++;
        while (s[i] != ' ' && s[i] != 0)
        {
            a[j].index = a[j].index * 10 + s[i] - '0';
            i++;
        }
        i++;
        j++;
    }
    return j;
}
int cmp(const void *x, const void *y)
{
    return ((num *)y)->index - ((num *)x)->index;
}
