// start 16:18
// about 3h
// 看清题目再写！
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
int igate = 0, cnt;
bool serachFlag = 0;
bool travelFlag = 1;
typedef struct node
{
    int val;
    // bool used;
    struct node *s[3];
} node;
node *root, *searchResult;
node *trees[500] = {0};
int itrees = 0;

typedef struct gate
{
    int num;
    int traffic;
} gate;
typedef struct seq
{
    node *val;
    struct seq *next;
} seq;
seq *front, *rear;
gate gates[100] = {{0}};
void searchTree(int val, node *now)
{
    if (serachFlag == 1 || now == NULL)
        return;
    else if (now->val == val)
    {
        searchResult = now;
        serachFlag = 1;
        return;
    }
    for (int i = 0; i < 3; i++)
    {
        searchTree(val, now->s[i]);
        if (serachFlag == 1)
            return;
    }
}
void createTree(int r)
{
    searchTree(r, root);
    serachFlag = 0;
    node *cur = searchResult;
    int n = 0;
    for (int i = 0; i < 3 && n != -1; i++)
    {
        scanf("%d", &n);
        if (n == -1)
            return;
        node *tmp = (node *)calloc(1, sizeof(node));
        tmp->val = n;
        cur->s[i] = tmp;
    }
    scanf("%d", &n);
    return;
}
int cmp(const void *x, const void *y)
{
    if (((gate *)x)->traffic == ((gate *)y)->traffic)
        return ((gate *)x)->num - ((gate *)y)->num;
    else
        return ((gate *)y)->traffic - ((gate *)x)->traffic;
}
seq *initialSeq()
{
    seq *tmp = (seq *)calloc(1, sizeof(seq));
    return tmp;
}
void enterSeq(node *cur)
{
    if (rear == NULL)
    {
        front = (seq *)calloc(1, sizeof(seq));
        rear = front;
        rear->val = cur;
        front->val = cur;
        return;
    }
    seq *tmp = (seq *)calloc(1, sizeof(seq));
    rear->next = tmp;
    tmp->val = cur;
    rear = tmp;
    if (front == NULL)
        front = rear;
}
seq *popSeq()
{
    seq *tmp = (front);
    (front) = (front)->next;
    if ((front) == rear && front->val == NULL)
    {
        rear = front = NULL;
    }
    return tmp;
}
void travelTree(node *cur)
{
    int icur = 0;
    if (cur == NULL)
        return;
    for (int j = 0; j < cnt + igate; j++)
    {
        seq *tmp = popSeq();
        trees[itrees++] = tmp->val;
        cur = trees[icur++];
        for (int i = 0; i < 3; i++)
        {
            if (cur->s[i] != NULL)
                enterSeq(cur->s[i]);
        }
    }
    return;
}
int main()
{
    int n = 0;
    root = (node *)calloc(1, sizeof(node));
    root->val = 100;
    scanf("%d", &n);
    while (n != -1)
    {
        cnt++;
        createTree(n);
        scanf("%d", &n);
    }
    while (scanf("%d", &(gates[igate].num)) != EOF)
    {
        scanf("%d", &(gates[igate++].traffic));
    }
    qsort(gates, igate, sizeof(gate), cmp);
    front = (seq *)calloc(1, sizeof(seq));
    front = initialSeq();
    enterSeq(root);
    travelTree(root);
    int j = 0;
    for (int i = 0; i < itrees; i++)
    {
        if (trees[i]->val >= 100)
            continue;
        printf("%d->%d\n", gates[j++].num, trees[i]->val);
    }
    for (int i = 0; i < itrees; i++)
    {
        free(trees[i]);
    }
    return 0;
}