#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    FILE *in, *out;
    char source[9000] = {0}, dest[9000] = {0};
    char *tag[1000];
    int i = 0;
    gets(source), gets(dest);
    int slen = strlen(source), dlen = strlen(dest);
    in = fopen("filein.txt", "r");
    out = fopen("fileout.txt", "w");
    fseek(in, 0, SEEK_END);
    int len = ftell(in);
    char *s = (char *)calloc(len + 1, sizeof(char));
    /*memset(s, 0, len * sizeof(char));*/
    rewind(in);
    fread(s, 1, len, in);
    char *buf = NULL;
    char *tmp = s;
    int m = 0;
    while (s[m] != '\0')
    {
        if (s[m] <= 'Z' && s[m] >= 'A')
            s[m] = s[m] - 'A' + 'a';
        m++;
    }
    buf = strstr(tmp, source);
    while (buf != NULL)
    {
        tag[i++] = buf;
        tmp = buf + slen;
        buf = strstr(tmp, source);
    }
    fflush(in), rewind(in);
    fread(s, 1, len, in);
    fclose(in), in = NULL;
    i = 0;
    int j = 0;
    while (s[i] != '\0')
    {
        if (&s[i] == tag[j])
        {
            fputs(dest, out);
            /*fseek(out, dlen, SEEK_CUR);*/
            i += slen;
            j++;
            /*if (j == 2)
            {
                fclose(out);
                return 0;
            }
            continue;*/
        }
        fputc(s[i], out);
        i++;
    }
    fclose(out);
    free(s);
    return 0;
}