#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
bool lflag = 0;
int m, n;

int main()
{
    char c[20] = {0};
    gets(c);
    if (c[1] == '-')
    {
        lflag = 1;
        sscanf(c + 2, "%d:%d", &m, &n);
    }
    else
        sscanf(c + 1, "%d:%d", &m, &n);
    char s[1000] = {0};
    getchar();
    gets(s);
    int len = strlen(s);
    s[m] = 0, s[len] = 0;
    if (m >= n)
    {
        printf("%s", s);
    }
    else
    {
        int tmp = strlen(s);
        if (lflag == 1)
        {
            for (int i = 0; i < n - tmp; i++)
                printf("#");
            printf("%s", s);
        }
        else
        {
            printf("%s", s);
            for (int i = 0; i < n - tmp; i++)
                printf("#");
        }
    }
    return 0;
}