#include <stdio.h>
#include <string.h>
char *rm(char *, int);
int main()
{
    char s[9999] = {0};
    gets(s);
    int slen = strlen(s);
    int j = 'z', m = 0;
    for (int i = slen; j >= 'a'; i++)
    {
        s[i] = j--;
    }
    char *str = rm(s, strlen(s)); // rm(char* s,int len)
    FILE *in = fopen("encrypt.txt", "r");
    FILE *out = fopen("output.txt", "w");
    memset(s, 0, 9999 * sizeof(char));
    fread(s, sizeof(char), 9999, in);
    slen = strlen(s);
    for (int i = 0; i < slen; i++)
    {
        if (s[i] <= 'z' && s[i] >= 'a')
            fputc(str[s[i] - 'a'], out);
        else
            fputc(s[i], out);
    }
    fclose(in), fclose(out);
    in = out = NULL;
    return 0;
}
char *rm(char *s, int n)
{
    char *tmp = s + 1;
    static char k[101] = {0};
    for (int i = 0; i < n; i++)
    {
        if (s[i] == ' ')
        {
            tmp++;
            continue;
        }
        char *buf = strchr(tmp, s[i]);
        while (buf != NULL)
        {
            *buf = ' ';
            buf = strchr(tmp, s[i]);
        }
        tmp++;
        buf = NULL;
    }
    int j = 0;
    for (int i = 0; s[i] != '\0'; i++)
    {
        if (s[i] == ' ')
            continue;
        k[j++] = s[i];
    }
    return k;
}