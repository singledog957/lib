// start:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define P 1000003
#define INF 0x7777777f

typedef struct _node
{
    char phone[12];
    char station;
    char in[7];
    char out[7];
    bool used;
} node;
node nodes[1000];
int inodes, ians;
node ans[1000];

bool check(node *val, node *key) // ���飬��׼
{
    if (val->station != key->station || val->used || strcmp(val->phone, key->phone) == 0 || val->used)
        return 0;
    if (strcmp(val->out, key->in) < 0 || strcmp(val->in, key->out) > 0)
        return 0;
    return 1;
}

node *searchPhone(char *key)
{
    int i = 0;
    for (; i < inodes; i++)
    {
        if (strcmp(nodes[i].phone, key) == 0 && !nodes[i].used)
            break;
    }
    if (i < inodes)
        return &nodes[i];
    return NULL;
}

void searchTime(node *res)
{
    for (int i = 0; i < inodes; i++)
    {
        if (check(&nodes[i], res))
        {
            memcpy(&ans[ians++], &nodes[i], sizeof(node));
            nodes[i].used = 1;
        }
    }
}

int cmp(const void *x, const void *y)
{
    int phone = strcmp(((node *)x)->phone, ((node *)y)->phone);
    if (phone == 0)
        return ((node *)x)->station - ((node *)y)->station;
    return phone;
}

int main()
{
    scanf("%d", &inodes);
    node *headPhone = NULL;
    for (int i = 0; i < inodes; i++)
    {
        scanf("%s %c %s %s", nodes[i].phone, &nodes[i].station, nodes[i].in, nodes[i].out);
    }
    node *res = NULL;
    char target[12];
    scanf("%s", target);
    res = searchPhone(target);
    while (res != NULL)
    {
        res->used = 1;
        searchTime(res);
        res = searchPhone(target);
    }
    qsort(ans, ians, sizeof(node), cmp);
    printf("%s %c\n", ans[0].phone, ans[0].station);
    for (int i = 1; i < ians; i++)
    {
        if (ans[i].station == ans[i - 1].station && strcmp(ans[i].phone, ans[i - 1].phone) == 0)
            continue;
        printf("%s %c\n", ans[i].phone, ans[i].station);
    }
    return 0;
}