#include <stdio.h>
#include <stdlib.h>
int n;
typedef struct line
{
    int x[2];
    int y[2];
    int num;
} line;
int cmp(const void *, const void *);
int cmp2(const void *, const void *);
int main()
{
    scanf("%d", &n);
    line m[102] = {{0}};
    for (int i = 0; i < n; i++)
    {
        m[i].num = 1;
        scanf("%d%d%d%d", &m[i].x[0], &m[i].y[0], &m[i].x[1], &m[i].y[1]);
    }
    /*qsort(m, n, sizeof(line), cmp2);*/
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i == j || m[j].x[0] == -1)
                continue;
            else if (m[j].x[0] == m[i].x[1] && m[j].y[0] == m[i].y[1])
            {
                m[i].x[1] = m[j].x[1], m[i].y[1] = m[j].y[1];
                m[i].num += m[j].num;
                m[j].x[0] = -1, m[j].y[0] = -1, m[j].num = 0;
                j = -1;
            }
        }
    }
    qsort(m, n, sizeof(line), cmp);
    printf("%d %d %d", m[0].num, m[0].x[0], m[0].y[0]);
    return 0;
}
int cmp(const void *x, const void *y)
{
    return ((line *)y)->num - ((line *)x)->num;
}
int cmp2(const void *x, const void *y)
{
    line *a = (line *)x;
    line *b = (line *)y;
    if (a->x[0] == b->x[0])
        return (a->y[0] >= b->y[0]) ? -1 : 1;
    else
        return (a->x[0] > b->x[0]) ? -1 : 1;
}