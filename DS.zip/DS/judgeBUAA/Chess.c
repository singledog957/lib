#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
bool row(int, int, int, int);
bool col(int, int, int, int);
bool Ucross(int, int, int, int);
bool Lcross(int, int, int, int);
typedef struct node
{
    int val;
    bool row;
    bool ucross;
    bool lcross;
    bool col;
} node;
node *a[23][23];
int main()
{
    int i = 0, j = 0;
    for (; i <= 19; i++)
    {
        for (j = 0; j <= 19; j++)
        {
            node *chess = (node *)calloc(1, sizeof(node));
            a[i][j] = chess;
        }
    }
    for (i = 0; i < 19; i++)
    {
        for (j = 0; j < 19; j++)
            scanf("%d", &(a[i][j]->val));
    }
    int n;
    for (n = 1; n <= 4 && a[1][n]->val == 1; n++)
        ;
    if (n == 5)
    {
        printf("1:2,2\n");
        return 0;
    }
    n = 0;
    for (n = 1; n <= 4 && a[n][1]->val == 1; n++)
        ;
    if (n == 5)
    {
        printf("1:2,2\n");
        return 0;
    }
    n = 1;
    for (int m = 1; m <= 4 && n <= 4 && a[m][n]->val == 1; m++, n++)
        ;
    if (n == 5)
    {
        printf("1:2,2\n");
        return 0;
    }
    for (j = 19, i = 0; i <= 19; i++)
        a[i][j]->val = -1;
    for (i = 19, j = 0; j <= 19; j++)
        a[i][j]->val = -1;
    for (i = 19, j = 19; j >= 0; j--)
        a[i][j]->val = -1;
    for (i = 19, j = 19; i >= 0; i--)
        a[i][j]->val = -1;
    for (i = 0; i < 19; i++)
    {
        for (j = 0; j < 19; j++)
        {
            if (a[i][j]->row || a[i][j] == 0)
                continue;
            if (row(i, j, 1, 0))
            {
                printf("1:%d,%d\n", i + 1, j + 1);
                return 0;
            }
            if (row(i, j, 2, 0))
            {
                printf("2:%d,%d\n", i + 1, j + 1);
                return 0;
            }
        }
    }
    for (j = 0; j < 19; j++)
    {
        for (i = 0; i < 19; i++)
        {
            if (a[i][j]->col || a[i][j] == 0)
                continue;
            if (col(i, j, 1, 0))
            {
                printf("1:%d,%d\n", i + 1, j + 1);
                return 0;
            }
            if (col(i, j, 2, 0))
            {
                printf("2:%d,%d\n", i + 1, j + 1);
                return 0;
            }
        }
    }
    for (i = 0; i < 19; i++)
    {
        for (j = 0; j < 19; j++)
        {
            if (a[i][j]->ucross || a[i][j] == 0)
                continue;
            if (Ucross(i, j, 1, 0))
            {
                printf("1:%d,%d\n", i - 2, j + 4);
                return 0;
            }
            if (Ucross(i, j, 2, 0))
            {
                printf("2:%d,%d\n", i - 2, j + 4);
                return 0;
            }
        }
    }
    for (i = 0; i < 19; i++)
    {
        for (j = 0; j < 19; j++)
        {
            if (a[i][j]->lcross || a[i][j] == 0)
                continue;
            if (Lcross(i, j, 1, 0))
            {
                printf("1:%d,%d\n", i + 1, j + 1);
                return 0;
            }
            if (Lcross(i, j, 2, 0))
            {
                printf("2:%d,%d\n", i + 1, j + 1);
                return 0;
            }
        }
    }
    printf("No\n");
    return 0;
}
bool row(int x, int y, int n, int depth)
{
    if (x >= 19 || y >= 19 || a[x][y]->val != n || a[x][y]->row == true)
        return false;
    if (depth == 3)
    {
        if (y - 4 < 0 && a[x][y + 1]->val != 0)
            return false;
        if (a[x][y - 4]->val != 0 && a[x][y + 1]->val != 0)
            return false;
        return true;
    }
    else
    {
        depth++;
        a[x][y]->row = true;
        if (row(x, y + 1, n, depth) == true)
            return true;
        return false;
    }
}
bool col(int x, int y, int n, int depth)
{
    if (x >= 19 || y >= 19 || a[x][y]->val != n || a[x][y]->col == true)
        return false;
    if (depth == 3)
    {
        if (x - 4 < 0 && a[x + 1][y]->val != 0)
            return false;
        if (a[x - 4][y]->val != 0 && a[x + 1][y]->val != 0)
            return false;
        return true;
    }
    else
    {
        depth++;
        a[x][y]->col = true;
        if (col(x + 1, y, n, depth) == true)
            return true;
        return false;
    }
}
bool Ucross(int x, int y, int n, int depth)
{
    if (x < 0 || y < 0 || a[x][y]->val != n)
        return false;
    if (depth == 3)
    {
        if ((x - 1 < 0) && a[x + 4][y - 4]->val == 0)
            return true;
        if ((y - 4 < 0) && a[x - 1][y + 1]->val != 0)
            return false;
        else if (a[x - 1][y + 1]->val != 0 && a[x + 4][y - 4]->val != 0)
            return false;
        return true;
    }
    else
    {
        a[x][y]->ucross = true;
        if (Ucross(x - 1, y + 1, n, depth + 1) == true)
            return true;
        return false;
    }
}
bool Lcross(int x, int y, int n, int depth)
{
    if ((depth < 3 && a[x][y]->val != n))
        return false;
    if (depth == 3)
    {
        if ((x - 4 < 0 || y - 4 < 0) && a[x + 1][y + 1]->val != 0)
            return false;
        else if (a[x + 1][y + 1]->val != 0 && a[x - 4][y - 4]->val != 0)
            return false;
        return true;
    }
    else
    {
        a[x][y]->lcross = true;
        if (Lcross(x + 1, y + 1, n, depth + 1) == true)
            return true;
        return false;
    }
}