#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
typedef struct book
{
    char name[51];
    char auth[21];
    char press[31];
    char date[11];
} book;
int n;
book *result[502];
void import(book *, book *); // import(head,cur)
void search(book *, char *); // search(head,key)
void delete(book *, char *); // delete(head,key)
void move(book *, int);
int cmp(const void *, const void *);
int main()
{
    FILE *lib = fopen("books.txt", "r");
    FILE *end = fopen("ordered.txt", "w");
    book entry[502] = {0};
    int i = 0;
    while (fscanf(lib, "%s%s%s%s", entry[i].name, entry[i].auth, entry[i].press, entry[i].date) != EOF)
    {
        i++;
    } // initial
    n = i;
    qsort(entry, n, sizeof(entry[0]), cmp);
    while (scanf("%d", &i))
    {
        switch (i)
        {
        case 1:
        {
            book now = {0};
            scanf("%s%s%s%s", now.name, now.auth, now.press, now.date);
            import(entry, &now);
            n++;
            fflush(stdin);
            break;
        }
        case 2:
        {
            int l = 0;
            char key[51] = {0};
            scanf("%s", key);
            search(entry, key);
            while (result[l] != NULL)
            {
                printf("%-49s %-19s %-29s %-9s\n", result[l]->name, result[l]->auth, result[l]->press, result[l]->date);
                l++;
            }
            memset(result, 0, sizeof(result[0]) * 502);
            fflush(stdin);
            break;
        }
        case 3:
        {
            char key[51] = {0};
            scanf("%s", key);
            delete (entry, key);
            fflush(stdin);
            break;
        }
        default:
        {
            for (int i = 0; i < n; i++)
            {
                if (entry[i].name[0] == ' ')
                {
                    n++;
                    continue;
                }
                fprintf(end, "%-49s %-19s %-29s %-9s\n", entry[i].name, entry[i].auth, entry[i].press, entry[i].date);
            }
            fclose(end), fclose(lib);
            return 0;
        }
        }
    }
}
int cmp(const void *x, const void *y)
{
    return strcmp(((book *)x)->name, ((book *)y)->name);
}
void import(book *entry, book *now) // import(head,cur)
{
    int i = 0;
    while (strcmp(entry[i].name, now->name) < 0 && i < n)
        i++;
    if (i == n)
    {
        memcpy(&(entry[i]), now, sizeof(entry[0]));
        return;
    }
    move(entry, i);
    memcpy(&(entry[i]), now, sizeof(entry[0]));
}
void search(book *entry, char *s) // search(head,key)
{
    char *cur = strstr(entry[0].name, s);
    int i = 0, m = 0;
    while (i < n)
    {
        if (entry[i].name[0] == ' ')
        {
            n++;
            continue;
        }
        if (cur != NULL)
        {
            result[m++] = &entry[i];
        }
        cur = strstr(entry[++i].name, s);
    }
}
void delete(book *entry, char *s) // delete(head,key)
{
    search(entry, s);
    for (int i = 0; result[i] != NULL; i++)
    {
        (result[i])->name[0] = ' ';
        n--;
    }
    memset(result, 0, sizeof(result[0]) * 502);
}
void move(book *entry, int x)
{
    memcpy(&entry[x + 1], &entry[x], (n - x) * sizeof(book));
}