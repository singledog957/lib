#include <stdio.h>
#include <stdlib.h>
int main()
{
    char tmp[20000];
    scanf("%[^EOF]", tmp);
    printf("%s", tmp);
    return 0;
}