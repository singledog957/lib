#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
void DFS(bool **edge, bool *visit, int node, int nodeSize, int *ans, int *ians)
{
    if (visit[node])
        return;
    visit[node] = 1;
    ans[(*ians)++] = node;
    for (int i = 0; i < nodeSize; i++)
    {
        if (edge[node][i] && !visit[i])
            DFS(edge, visit, i, nodeSize, ans, ians);
    }
    return;
}
void BFS(bool **edge, int node, int nodeSize, bool *visit, int *seq, int *rear, int *top, int *ans, int *ians)
{
    if (visit[node])
        return;
    ans[(*ians)++] = node;
    for (int i = 0; i < nodeSize; i++)
    {
        if (edge[node][i] && !visit[i])
            seq[(*rear)++] = i;
    }
    visit[node] = 1;
    while (*top != *rear + 1)
    {
        (*top)++;
        BFS(edge, seq[*top - 1], nodeSize, visit, seq, rear, top, ans, ians);
    }
    return;
}
void print(int nodes, int *ans)
{
    for (int i = 0; i < nodes; i++)
        printf("%d ", ans[i]);
    printf("\n");
}
int main()
{
    int nodes, edges;
    scanf("%d %d", &nodes, &edges);
    bool **edge = (bool **)calloc(nodes + 1, sizeof(bool *));
    for (int i = 0; i < nodes; i++)
        edge[i] = (bool *)calloc(nodes + 1, sizeof(bool));
    int s, e;
    for (int i = 0; i < edges; i++)
    {
        scanf("%d %d", &s, &e);
        edge[s][e] = 1;
        edge[e][s] = 1;
    }
    for (int i = 0; i < nodes; i++)
        edge[i][i] = 1;
    int *ans = (int *)calloc(nodes, sizeof(int));
    bool *visit = (bool *)calloc(nodes, sizeof(bool));
    int ians = 0;
    DFS(edge, visit, 0, nodes, ans, &ians);
    print(nodes, ans);
    memset(visit, 0, sizeof(bool) * nodes);
    memset(ans, 0, sizeof(int) * nodes);
    int *seq = (int *)calloc(nodes * nodes, sizeof(int));
    ians = 0;
    int rear = 0, top = 0;
    BFS(edge, 0, nodes, visit, seq, &rear, &top, ans, &ians);
    print(nodes, ans);
    int del;
    scanf("%d", &del);
    // del
    for (int i = 0; i < nodes; i++)
        edge[i][del] = 0;
    // endDel
    memset(ans, 0, sizeof(int) * nodes);
    memset(visit, 0, sizeof(bool) * nodes);
    ians = 0;
    DFS(edge, visit, 0, nodes, ans, &ians);
    print(nodes - 1, ans);
    memset(visit, 0, sizeof(bool) * nodes);
    memset(seq, 0, sizeof(bool) * nodes * nodes);
    ians = 0, top = 0, rear = 0;
    BFS(edge, 0, nodes, visit, seq, &rear, &top, ans, &ians);
    print(nodes - 1, ans);
    for (int i = 0; i < nodes; i++)
        free(edge[i]);
    free(edge);
    free(ans), free(seq), free(visit);
    return 0;
}