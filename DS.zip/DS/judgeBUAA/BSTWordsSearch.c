// start 19:10
// end 20:39
// 题目难以理解
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
bool flag = 0;
typedef struct tree
{
    char *s;
    int freq;
    struct tree *left;
    struct tree *right;
} tree;
FILE *in;
tree *head;
char *getWord()
{
    if (feof(in) != 0)
    {
        flag = 1;
        return NULL;
    }
    char *s = (char *)calloc(100, sizeof(char));
    int i = 0;
    char c = fgetc(in);
    while (isalpha(c) == 0)
    {
        if (feof(in) != 0)
        {
            flag = 1;
            return NULL;
        }
        c = fgetc(in);
    }
    while (isalpha(c))
    {
        s[i++] = tolower(c);
        c = fgetc(in);
    }
    return s;
}
void createBitree(char *words, tree *root)
{
    if (root == NULL || words == NULL)
        return;
    tree *pre = root;
    int judge;
    while (root != NULL)
    {
        judge = strcmp(words, (root)->s);
        pre = root;
        if (judge > 0)
            root = (root)->right;
        else if (judge < 0)
            root = (root)->left;
        else
        {
            (root)->freq++;
            break;
        }
    }
    if (root == NULL)
    {
        root = (tree *)calloc(1, sizeof(tree));
        (root)->s = words;
        if (judge > 0)
            pre->right = root;
        else
            pre->left = root;
    }
}
void travel(tree *root)
{
    if (root == NULL)
        return;
    travel(root->left);
    printf("%s %d\n", root->s, root->freq + 1);
    travel(root->right);
    free(root->s), free(root);
}
int main()
{
    head = (tree *)calloc(1, sizeof(tree));
    in = fopen("article.txt", "r");
    head->s = getWord();
    while (flag == 0)
    {
        createBitree(getWord(), head);
    }
    tree *cur = head;
    int i = 0;
    for (; cur != NULL && i < 2; i++)
    {
        printf("%s ", cur->s);
        cur = cur->right;
    }
    if (cur != NULL)
        printf("%s\n", cur->s);
    else if (cur == NULL)
        printf("\n");
    travel(head);
    return 0;
}