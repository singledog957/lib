#include <stdio.h>
#include <string.h>
char dif[200] = {0};
int subLen, minuLen;
void minus(char *, char *);
int cmp(char *, char *, int);
int main()
{
    char minu[200] = {0}, sub[200] = {0};
    int q = 0;
    gets(sub), gets(minu);
    int i = 0;
    while (sub[i] == '0')
        i++;
    strcpy(sub, sub + i);
    i = 0;
    while (minu[i] == '0')
        i++;
    strcpy(minu, minu + i);
    subLen = strlen(sub), minuLen = strlen(minu);
    if (subLen == minuLen)
        q = cmp(sub, minu, subLen);
    if (subLen < minuLen || q)
    {
        minus(minu, sub);
        printf("-%s", dif);
    }
    else
    {
        minus(sub, minu);
        printf("%s", dif);
    }
    return 0;
}
void minus(char *x, char *y)
{
    int xlen = strlen(x), ylen = strlen(y);
    int diff = 0;
    for (int i = xlen - 1, j = ylen - 1; j >= 0; j--, i--)
    {
        diff = x[i] - y[j];
        if (diff < 0)
        {
            x[i] = 10 + diff + '0';
            x[i - 1]--;
            continue;
        }
        x[i] = diff + '0';
    }
    for (int i = xlen - 1; i >= 0; i--)
    {
        if (x[i] < '0')
        {
            x[i - 1]--;
            x[i] = 10 + x[i];
        }
    }
    int i = 0;
    while (x[i] == '0')
        i++;
    strcpy(dif, x + i);
    if (x[i] == 0)
        dif[0] = '0';
}
int cmp(char *x, char *y, int len)
{
    int i = 0;
    while (i <= len)
    {
        if (x[i] < y[i])
            return 1;
        i++;
    }
    return 0;
}