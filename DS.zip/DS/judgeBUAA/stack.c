#include <stdio.h>
#include <stdlib.h>
typedef struct node
{
    int val;
    struct node *next;
    struct node *pre;
} node;
void pop(node **);
void enter(node **, int);
int main()
{
    int n = 0, m = 0, cnt = 0;
    node *head = (node *)calloc(1, sizeof(node));
    node *s = head;
    scanf("%d", &n);
    while (n != -1)
    {
        if (n == 1)
        {
            if (cnt == 100)
            {
                printf("error ");
                continue;
            }
            scanf("%d", &m);
            enter(&s, m);
            cnt++;
        }
        else if (n == 0)
        {
            if (s == NULL)
            {
                printf("error ");
                continue;
            }
            pop(&(s->pre));
            cnt--;
        }
        scanf("%d", &n);
    }
    return 0;
}
void enter(node **s, int n)
{
    (*s)->val = n;
    node *q = (node *)calloc(1, sizeof(node));
    (*s)->next = q;
    q->pre = (*s);
    (*s) = q;
}
void pop(node **s)
{
    if ((*s) == NULL)
    {
        printf("error ");
        return;
    }
    printf("%d ", (*s)->val);
    if ((*s)->pre == NULL)
    {
        *s = NULL;
        return;
    }
    *s = (*s)->pre;
    free((*s)->next);
    (*s)->next = NULL;
}