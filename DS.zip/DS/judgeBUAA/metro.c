// վ�����ַ����Ĳ����𡣡���
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#define P 1000003
#define WORDSSIZE 30
typedef struct TrieNode
{
    struct TrieNode *children[2550]; // �ӽڵ�����
    bool is_word;                    // ����Ƿ���һ�������Ĵ�
    int node;
} TrieNode;
typedef struct Edge
{
    int weight;
    int lineNum;
    char s[WORDSSIZE];
    bool isTrans;
} Edge;
typedef struct NL
{
    char name[WORDSSIZE];
    bool isTrans;
} NL;
// ����һ���µ��ֵ����ڵ�
TrieNode *createNode()
{
    TrieNode *newNode = (TrieNode *)calloc(1, sizeof(TrieNode));
    return newNode;
}

// ���ֵ����в���һ����
void insert(TrieNode *root, const char *word, int num)
{
    TrieNode *node = root;
    while (*word)
    {
        unsigned char index = *word; // ��ȡ��ǰ�ַ���GBK����ֵ
        if (node->children[index] == NULL)
        {
            node->children[index] = createNode();
        }
        node = node->children[index];
        word++;
    }
    node->node = num;
    node->is_word = true; // ��ǵ�ǰ�ڵ�Ϊһ�������Ĵ�
}

// ���ֵ���������һ����
int search(TrieNode *root, const char *word)
{
    TrieNode *now = root;
    while (*word)
    {
        unsigned char index = *word; // ��ȡ��ǰ�ַ���GBK����ֵ
        if (now->children[index] == NULL)
        {
            return -1; // δ�ҵ��ô�
        }
        now = now->children[index];
        word++;
    }
    if (now->is_word)
        return now->node;
    return -1;
}

int getEdge(Edge **edge, int x, FILE *in, TrieNode *root)
{
    int iedge = 0;
    for (int i = 0; i < x; i++)
    {
        int linenum, stationSize, ctl, pre = iedge;
        fscanf(in, "%d %d", &linenum, &stationSize);
        for (int j = 0; j < stationSize; j++)
        {
            char tmp[50] = {0};
            fscanf(in, "%s %d", tmp, &ctl);
            int index = iedge;
            if (ctl)
            {
                int itmp = search(root, tmp);
                if (itmp != -1)
                    index = itmp;
                edge[index][index].isTrans = 1;
            }
            if (index == iedge)
            {
                insert(root, tmp, iedge);
                edge[index][index].lineNum = linenum;
            }
            edge[pre][index].weight = 1;
            edge[pre][index].lineNum = linenum;
            edge[index][pre].weight = 1;
            edge[index][pre].lineNum = linenum;
            strcpy(edge[pre][index].s, tmp);
            strcpy(edge[index][index].s, tmp);
            strcpy(edge[index][pre].s, edge[pre][pre].s);
            // printf("%d-%d:%s\n", pre, index, edge[pre][index].s);
            if (pre == index)
            {
                edge[index][pre].weight = P;
                edge[index][pre].lineNum = linenum;
            }
            pre = index;
            iedge++;
        }
    }
    return iedge;
}

int *shortRoute(Edge **edge, int start, int end, int nodeSize, int *routeSize)
{
    int *dist = calloc(nodeSize, sizeof(int));
    int *route = calloc(nodeSize, sizeof(int));
    bool *visit = calloc(nodeSize, sizeof(bool));
    for (int i = 0; i < nodeSize; i++)
    {
        if (edge[start][i].weight)
        {
            dist[i] = edge[start][i].weight;
            route[i] = start;
        }
        else
            dist[i] = P;
    }
    dist[start] = 0;
    int now = start;
    int min = P, imin = start;
    /*for (int i = 0; i < nodeSize; i++)
    {
        if (edge[now][i].weight < min && !visit[i] && edge[now][i].weight != 0)
        {
            imin = i;
            min = edge[now][i].weight;
        }
    }*/
    visit[start] = 1;
    now = imin;
    /*for (int i = 0; i < nodeSize; i++)
    {
        if (dist[i])
            printf("%d ", dist[i]);
    }*/
    route[start] = start;
    int times = nodeSize;
    while (times--)
    {
        min = P;
        visit[now] = 1;
        for (int i = 0; i < nodeSize; i++)
        {
            if (dist[i] < min && !visit[i])
            {
                imin = i;
                min = dist[i];
            }
        }
        // route[imin] = now;
        now = imin;
        for (int i = 0; i < nodeSize; i++)
        {
            if (edge[now][i].weight != P && !visit[i] && edge[now][i].weight != 0 && dist[i] > dist[now] + 1)
            {
                dist[i] = dist[now] + edge[now][i].weight;
                route[i] = imin;
            }
        }
        /*for (int i = 0; i < nodeSize; i++)
        {
            if (dist[i] != P)
                printf("%d:%d ", i, dist[i]);
        }
        puts("");*/
    }
    // free(dist), free(visit);
    return route;
}

int main()
{
    FILE *in = fopen("bgstations.txt", "r");
    // FILE *out = fopen("out.txt", "w");

    TrieNode *root = createNode();
    int x;
    fscanf(in, "%d", &x);
    Edge **edge = calloc(500, sizeof(Edge *));
    for (int i = 0; i < 500; i++)
    {
        edge[i] = calloc(500, sizeof(Edge));
        edge[i][i].weight = P;
    }
    int iedge = getEdge(edge, x, in, root);
    NL *nameList = calloc(iedge, sizeof(NL));
    // debug
    /*for (int i = 0; i < iedge; i++)
    {
        fprintf(out, "Current Station:%s\n", edge[i][i].s);
        //printf(" id:%d\n", edge[i][i].lineNum);
        for (int j = 0; j < iedge; j++)
        {
            if (edge[i][j].weight)
                fprintf(out, "Station:%s  id:%d line:%d\n", edge[i][j].s, search(root, edge[i][j].s), edge[i][j].lineNum);
        }
        fprintf(out, "\n");
    }
    fclose(out);*/
    for (int i = 0; i < iedge; i++)
    {
        int index = search(root, edge[i][i].s);
        if (index != -1)
        {
            strcpy(nameList[index].name, edge[i][i].s);
            nameList[index].isTrans = edge[i][i].isTrans;
        }
    }
    char start[WORDSSIZE] = {0}, end[WORDSSIZE] = {0};
    scanf("%s %s", start, end);
    int startIndex = search(root, start);
    int endIndex = search(root, end);
    int routeSize = 0;
    int *route = shortRoute(edge, startIndex, endIndex, iedge, &routeSize);
    // printf("---------\n");
    int v = endIndex;
    int *pRoute = calloc(iedge, sizeof(int));
    int ir = 0;
    while (v != startIndex)
    {
        pRoute[ir++] = v;
        v = route[v];
    }
    pRoute[ir] = startIndex;
    // for (int i = ir; i > 0; i--)
    // printf("%s:%d,Line:%d->", nameList[pRoute[i]].name, pRoute[i], edge[pRoute[i]][pRoute[i - 1]].lineNum);
    printf("%s-%d", nameList[pRoute[ir]].name, edge[pRoute[ir - 1]][pRoute[ir]].lineNum);
    int scnt = 1;
    int fuckNum = edge[pRoute[ir - 1]][pRoute[ir]].lineNum;
    ir--;
    while (ir > 0)
    {
        if (fuckNum != edge[pRoute[ir]][pRoute[ir - 1]].lineNum)
        {
            fuckNum = edge[pRoute[ir]][pRoute[ir - 1]].lineNum;
            printf("(%d)-%s-%d", scnt, nameList[pRoute[ir]].name, fuckNum);
            scnt = 0;
        }
        ir--;
        scnt++;
    }
    printf("(%d)-%s", scnt, nameList[pRoute[0]].name);
    return 0;
}
// toDo:
// iweight����
//