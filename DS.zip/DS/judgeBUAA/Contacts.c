#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct contact
{
    char name[25];
    char num[12];
} contact;
void dup(contact *, int);
int cmp(const void *x, const void *y);
int main()
{
    contact peo[101] = {0};
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%s%s", peo[i].name, peo[i].num);
    }
    for (int i = 0; i < n; i++)
    {
        int k = 0;
        for (int j = i + 1; j < n; j++)
        {
            if (strcmp(peo[i].name, peo[j].name) == 0)
            {
                if (strcmp(peo[i].num, peo[j].num) == 0)
                    peo[j].name[0] = '0';
                else
                    dup(&peo[j], ++k);
            }
        }
        k = 0;
    }
    qsort(peo, n, sizeof(peo[0]), cmp);
    for (int i = 0; i < n; i++)
    {
        if (peo[i].name[0] == '0')
            continue;
        printf("%s %s\n", peo[i].name, peo[i].num);
    }
    return 0;
}
void dup(contact *x, int n)
{
    sprintf(x->name, "%s_%d", x->name, n);
}
int cmp(const void *x, const void *y)
{
    return strcmp(((contact *)x)->name, ((contact *)y)->name);
}