#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
char *rm(char *s, int n)
{
    char *tmp;
    for (int j = 0; j < 200; j++)
    {
        for (int i = 0; i < strlen(s); i++)
        {
            tmp = strchr(s + 1 + i, s[i]);
            if (tmp != NULL)
            {
                memcpy(tmp, tmp + 1, sizeof(char) * (strlen(tmp + 1)));
                s[strlen(s) - 1] = 0;
            }
        }
    }
    return s;
    /*
    char *tmp = s + 1;
    static char k[101] = {0};
    for (int i = 0; i < n; i++)
    {
        if (s[i] == ' ')
        {
            tmp++;
            continue;
        }
        char *buf = strchr(tmp, s[i]);
        while (buf != NULL)
        {
            *buf = ' ';
            buf = strchr(tmp, s[i]);
        }
        tmp++;
        buf = NULL;
    }
    int j = 0;
    for (int i = 0; s[i] != '\0'; i++)
    {
        if (s[i] == ' ')
            continue;
        k[j++] = s[i];
    }
    return k;
    */
}
void reverse(char *s, int len)
{
    int j = 0;
    char str[101] = {0};
    for (int i = len - 1; i >= 0; i--)
    {
        str[j++] = s[i];
    }
    memset(s, 0, sizeof(char) * 51);
    strcpy(s, str);
}
int main()
{
    char s[101] = {0};
    gets(s);
    int slen = strlen(s);
    s[slen] = 0;
    int k = 0;
    char dd[101] = {0};
    int spaceFlag = 0;
    for (int i = 0; i < 50; i++)
    {
        if (s[i] != ' ')
        {
            spaceFlag = 1;
            break;
        }
    }
    if (spaceFlag == 0)
    {
        for (int i = 'a'; i <= 'z'; i++)
            printf("%c", i);
        puts("");
        for (int i = 'z'; i >= 0; i--)
            printf("%c", i);
        return 0;
    }
    for (int i = 0; i < slen; i++)
    {
        if (isalpha(s[i]))
        {
            dd[k++] = tolower(s[i]);
        }
    }
    dd[k] = 0;
    memset(s, 0, sizeof(char) * 101);
    memcpy(s, dd, sizeof(char) * 101);
    k = 0;
    for (int j = 0; j < 200; j++)
    {
        for (int i = 0; i < strlen(s); i++)
        {
            char *tmp = strchr(s + i + 1, s[i]);
            if (tmp != NULL)
            {
                memcpy(tmp, tmp + 1, sizeof(char) * strlen(tmp + 1));
                s[strlen(s) - 1] = 0;
            }
        }
    }
    slen = strlen(s);
    reverse(s, slen);
    int j = 'z';
    slen = strlen(s);
    for (int i = slen; j >= 'a'; i++)
    {
        s[i] = j--;
    }
    slen = strlen(s);
    char *str = rm(s, slen);
    for (int i = 'a'; i <= 'z'; i++)
        printf("%c", i);
    puts("");
    printf("%s", str);
    return 0;
}