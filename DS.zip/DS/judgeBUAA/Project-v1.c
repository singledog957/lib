// 5.7 1.5h
// 5.8 1.5h
// 5.9 4h rewrite
// 5.10 3h
// 5.11 1h fin
// 原始
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#define MAXWORDSSIZE 10000
#define SAMPLENUM 10000
#define ARTICLENUM 15000
#define STOPWORDSNUM 20000
#define HASHNUM 10000
#define MAXWORDSNUM 500000
#define MAXWORDSPER 100000
#define TITLELEN 100
#define MAXTITLE 10000
FILE *stopword, *sample, *article, *hashvalue, *result, *debug;
typedef struct word
{
    char s[MAXWORDSSIZE];
    int times;
} word;
int istop, isample, iarticle;
char **stopwords, **hash, **featureArticle; //**featureSample,
char **numSample, **numArticle;
char **fingerSample, **fingerArticle;
int **weightSample, **weightArticle;
char ****cmpResult; // cmpResult[isample][hamming][i],char*
char *strcasestr(const char *str1, const char *str2)
{
    char *cp = (char *)str1;
    char *s1, *s2;

    if (!*str2)
        return (char *)str1;

    while (*cp)
    {
        s1 = cp;
        s2 = (char *)str2;

        while (*s1 && *s2 && !(tolower(*s1) - tolower(*s2)))
            s1++, s2++;
        if (!*s2)
            return cp;
        cp++;
    }

    return NULL;
}
void fileOpen()
{
    stopword = fopen("stopwords.txt", "r");
    sample = fopen("sample.txt", "r");
    article = fopen("article.txt", "r"); // article.txt
    hashvalue = fopen("hashvalue.txt", "r");
    result = fopen("result.txt", "w");
    // debug = fopen("debug.txt", "r");
}
void fileClose()
{
    fclose(stopword);
    fclose(sample);
    fclose(article);
    fclose(hashvalue);
    fclose(result);
    // fclose(debug);
}
int cmp(const void *x, const void *y)
{
    if (((word *)x)->times == ((word *)y)->times)
        return strcmp(((word *)x)->s, ((word *)y)->s);
    else
        return ((word *)y)->times - ((word *)x)->times;
}
void getHash(int N, int M)
{
    char tmp[129] = {0};
    for (int i = 0; i < N; i++)
    {
        hash[i] = (char *)calloc(M + 1, sizeof(char));
        fscanf(hashvalue, "%s", tmp);
        for (int j = 0; j < M; j++)
            strncpy(hash[i], tmp, M);
        hash[i][M] = 0;
    }
}
int judgeHash(int row, int col)
{
    if (hash[row][col] == '0')
        return -1;
    else
        return 1;
}
void getStopWords()
{
    char s[MAXWORDSSIZE];
    while (fscanf(stopword, "%s", s) != EOF)
    {
        stopwords[istop] = (char *)calloc(MAXWORDSSIZE, sizeof(char));
        strcpy(stopwords[istop++], s);
    }
}
char *searchStopWords(char *s)
{
    int low = 0, high = istop - 1;
    int mid = istop / 2;
    while (low <= high)
    {
        int res = strcmp(s, stopwords[mid]);
        if (res < 0)
            high = mid - 1;
        else if (res > 0)
            low = mid + 1;
        else
            return stopwords[mid];
        mid = (high + low) / 2;
    }
    return NULL;
    /*for (int i = 0; i < istop; i++)
    {
        if (strcmp(s, stopwords[i]) == 0)
            return stopwords[i];
    }
    return NULL;*/
}
word *searchWords(word *words, char *key, int iwords)
{
    for (int i = 0; i < iwords; i++)
    {
        if (strcmp(key, words[i].s) == 0)
            return &(words[i]);
    }
    return NULL;
}
void getFeature(int N, int ctl) // 0 for sample,1 for article
{
    int iwords = 0;
    FILE *webpage = sample;
    char **feature;                                          //= featureSample;
    word *words = (word *)calloc(MAXWORDSNUM, sizeof(word)); // 数量未知
    if (ctl)
    {
        webpage = article;
        feature = featureArticle;
    }
    word *now = (word *)calloc(1, sizeof(word));
    while (fscanf(webpage, "%[a-zA-Z]", now->s) != EOF)
    {
        fgetc(webpage);
        if (now == NULL || (now->s)[0] == 0)
            continue;
        int len = strlen(now->s);
        (now->s)[len] = 0;
        for (int i = 0; i < len; i++)
            (now->s)[i] = tolower((now->s)[i]);
        word *tmp = searchWords(words, now->s, iwords);
        if (tmp != NULL)
            tmp->times++;
        else if (searchStopWords(now->s) == NULL)
            memcpy(&(words[iwords++]), now, sizeof(word));
        memset(now, 0, sizeof(word));
    }
    // memset(&(words[iwords]), 0, sizeof(word));
    qsort(words, iwords, sizeof(word), cmp);
    for (int i = 0; i < N; i++)
    {
        int len = strlen(words[i].s);
        feature[i] = (char *)calloc(len + 1, sizeof(char));
        strcpy(feature[i], words[i].s);
    }
    free(words);
    rewind(sample), rewind(article); // 注意rewind
}
void getWeight(int ctl, int N) // 0 for sample,1 for article,all doc
{
    FILE *webpage = sample;
    char **feature = featureArticle; // featureSample;
    int **weight = weightSample;
    int iweight = isample;
    if (ctl)
    {
        webpage = article;
        feature = featureArticle;
        weight = weightArticle;
        iweight = iarticle;
    }
    char line[MAXWORDSPER]; // 假设每篇最多10万词
    while (fscanf(webpage, "%[^\f]", line) != EOF)
    {
        fgetc(webpage); // 文件指针后移
        char *loc = line;
        if (ctl == 0)
        {
            loc = strcasestr(line, "Sample");
            numSample[isample] = (char *)calloc(TITLELEN, sizeof(char)); // sample len未知
            sscanf(loc, "%s", numSample[isample++]);
        }
        else
        {
            char tmp[100];
            sscanf(loc, "%s", tmp);
            while (*tmp == '\n')
                sscanf(loc + 1, "%s", tmp);
            numArticle[iarticle] = (char *)calloc(TITLELEN, sizeof(char)); // article len未知
            strcpy(numArticle[iarticle], tmp);
            loc += strlen(numArticle[iarticle++]) + 1;
            while (*loc == '\n')
                loc++;
        }
        weight[iweight] = (int *)calloc(N + 1, sizeof(int));
        char *start = loc;
        loc = strcasestr(loc, feature[0]);
        for (int i = 0; i < N; i++)
        {
            int flen = strlen(feature[i]);
            loc = strcasestr(start, feature[i]);
            while (loc != NULL)
            {
                if ((isalpha(*(loc - 1)) + isalpha(*(loc + flen))) == 0)
                {
                    weight[iweight][i]++;
                }
                loc = loc + strlen(feature[i]);    // 大概优化？
                loc = strcasestr(loc, feature[i]); // 是否应在feature前后追加空格以避免字符串中被匹配？
            }
            loc = start;
        }
        iweight = (ctl == 0) ? isample : iarticle;
    }
}
void createFinger(int ctl, int N, int M) // all docs，重写到全局
{
    int iweb = isample;
    int **weight = weightSample;
    char **finger = fingerSample; // fingerArticle;
    if (ctl)
    {
        iweb = iarticle;
        weight = weightArticle;
        finger = fingerArticle;
    }
    int sign = 0;
    for (int i = 0; i < iweb; i++)
    {
        finger[i] = (char *)calloc(M + 1, sizeof(char));
        for (int k = 0; k < M; k++)
        {
            for (int j = 0; j < N; j++)
                sign += weight[i][j] * judgeHash(j, k); // weight正确？sign
            finger[i][k] = (sign > 0) ? '1' : '0';
            sign = 0;
        }
    }
}
int getHamming(int sample, int article, int M)
{
    int cnt = M;
    for (int i = 0; i < M; i++)
        cnt -= (fingerArticle[article][i] == fingerSample[sample][i]);
    return cnt;
}
void cmpFinger(int M)
{
    for (int i = 0; i < isample; i++)
    {
        int cnt[4] = {0};
        for (int j = 0; j < iarticle; j++)
        {
            int index = getHamming(i, j, M);
            if (index > 3)
                continue;
            else // cmpResult[isample][hamming][i],char*
                cmpResult[i][index][cnt[index]++] = numArticle[j];
        }
    }
}
void print()
{
    for (int i = 0; i < 4; i++)
    {
        int j = 0;
        if (cmpResult[0][i][0] != NULL)
            printf("%d:", i);
        for (j = 0; cmpResult[0][i][j] != NULL; j++)
            printf("%s ", cmpResult[0][i][j]);
        if (j != 0)
            puts("");
    }
}
void fprint()
{
    for (int i = 0; i < isample; i++) // cmpResult[isample][hamming][i],char*
    {
        fprintf(result, "%s\n", numSample[i]);
        for (int j = 0; j < 4; j++)
        {
            int k = 0;
            if (cmpResult[i][j][0] != NULL)
                fprintf(result, "%d:", j);
            for (k = 0; cmpResult[i][j][k] != NULL; k++)
            {
                fprintf(result, "%s ", cmpResult[i][j][k]);
                // free(cmpResult[i][j][k]);
            }
            if (k != 0)
                fprintf(result, "\n");
            // free
            free(cmpResult[i][j]);
        }
        free(cmpResult[i]);
    }
    free(cmpResult);
}
void charfree(char **p, int n)
{
    for (int i = 0; i < n; i++)
        free(p[i]);
    free(p);
}
void numfree(int **p, int n)
{
    for (int i = 0; i < n; i++)
        free(p[i]);
    free(p);
}
int main(int argc, char *argv[])
{
    fileOpen();
    int N, M;
    N = atoi(argv[1]), M = atoi(argv[2]);
    // scanf("%d%d", &N, &M);
    stopwords = (char **)calloc(STOPWORDSNUM, sizeof(char *)); // 数量未知,对于stopwords与hash,无需传参
    hash = (char **)calloc(HASHNUM, sizeof(char *));           // 数量未知
    getStopWords();
    getHash(N, M);
    // featureSample = (char **)calloc(N, sizeof(char *));
    featureArticle = (char **)calloc(N, sizeof(char *)); // 初始化结束
    // getFeature(N, 0);
    getFeature(N, 1); // debug on
    /*for (int i = 0; i < N; i++)
    {
        featureArticle[i] = (char *)calloc(MAXWORDSSIZE, sizeof(char));
        fscanf(debug, "%s", featureArticle[i]);
        // fprintf(debug, "%s\n", featureArticle[i]);
    }
    // finger = (char **)calloc(N, sizeof(char *));*/
    weightSample = (int **)calloc(SAMPLENUM, sizeof(int *));   // 文章篇数未知
    weightArticle = (int **)calloc(ARTICLENUM, sizeof(int *)); // 文章篇数未知
    numSample = (char **)calloc(SAMPLENUM, sizeof(char *));
    numArticle = (char **)calloc(ARTICLENUM, sizeof(char *));
    fingerArticle = (char **)calloc(ARTICLENUM, sizeof(char *));
    fingerSample = (char **)calloc(SAMPLENUM, sizeof(char *));
    getWeight(0, N);
    getWeight(1, N);
    createFinger(0, N, M);
    createFinger(1, N, M);
    cmpResult = (char ****)calloc(isample, sizeof(char ***)); // cmpResult[isample][hamming][i],char*
    for (int i = 0; i < isample; i++)
    {
        cmpResult[i] = (char ***)calloc(4, sizeof(char **));
        for (int j = 0; j < 4; j++)
            cmpResult[i][j] = (char **)calloc(MAXTITLE, sizeof(char *)); // 假设每个汉明值最多100个标题
    }
    cmpFinger(M);
    print();
    fprint();
    charfree(stopwords, STOPWORDSNUM);
    charfree(hash, N);
    charfree(featureArticle, N);
    numfree(weightSample, isample);
    numfree(weightArticle, iarticle);
    charfree(numArticle, iarticle);
    charfree(numSample, isample);
    charfree(fingerArticle, iarticle);
    charfree(fingerSample, isample);
    fileClose();
    return 0;
}
// 可能的优化
// 构造feature时构造字典树,getWeight时查找加快
//  利用字符串hash
//
//
