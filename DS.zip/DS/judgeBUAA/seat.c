// 怎样清楚地表�??
//  https://www.lifehack.org/710722/how-to-explain-things-better
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
typedef struct stu
{
    char name[21];
    int num;
    int seat;
} stu;
stu *students;
FILE *in, *out;
void debug(int x)
{
    for (int i = 0; i < x; i++)
        printf("%d %s %d\n", students[i].num, students[i].name, students[i].seat);
    printf("\n");
}
void swap(stu *a, stu *b)
{
    stu tmp;
    memcpy(&tmp, a, sizeof(stu));
    memcpy(a, b, sizeof(stu));
    memcpy(b, &tmp, sizeof(stu));
}
void bubbleSort(int inums)
{
    int flag = 1;
    int j = 1;
    while (flag)
    {
        flag = 0;
        for (int i = 0; i < inums - j; i++)
        {
            if (students[i].seat > students[i + 1].seat)
            {
                swap(&students[i], &students[i + 1]);
                flag = 1;
            }
        }
        // debug(inums);
        j++;
    }
}
int lineSearch(int key, int x)
{
    for (int i = 0; i < x; i++)
    {
        if (key == students[i].seat)
            return 1;
    }
    return 0;
}
void checkSeat(int x)
{
    int M = students[x - 1].seat;
    int Q = M < x ? M : x;
    int j = x;
    bool *flag = (bool *)calloc(x, sizeof(bool));
    for (int i = 0; i < Q; i++)
    {
        // Q = students[x - 1].seat < x ? students[x - 1].seat : x;
        int res = lineSearch(i + 1, x);
        if (res == 0)
            flag[i] = 1;
    }
    for (int i = 0; i < x; i++)
        printf("%d", flag[i]);
    for (int i = 0; i < Q; i++)
    {
        Q = students[j - 1].seat < x ? students[j - 1].seat : x;
        if (flag[i])
            students[--j].seat = i + 1;
    }
    int max = 0;
    debug(x);
    Q = students[x - 1].seat < x ? students[x - 1].seat : x;
    for (int i = 0; i < x; i++)
        max = max > students[i].seat ? max : students[i].seat;
    // max = 13;
    for (int i = 0; i < x - 1; i++)
    {
        // Q = students[x - 1].seat < x ? students[x - 1].seat : x;
        if (students[i].seat == students[i + 1].seat)
        {
            int tmp = students[i].num > students[i + 1].num ? i : i + 1;
            students[tmp].seat = ++max;
        }
    }
}
int cmp(const void *x, const void *y)
{
    return ((stu *)x)->num - ((stu *)y)->num;
}

int main()
{
    in = fopen("in.txt", "r");
    out = fopen("out.txt", "w");
    int x;
    scanf("%d", &x);
    students = (stu *)calloc(x + 1, sizeof(stu));
    for (int i = 0; i < x; i++)
    {
        fscanf(in, "%d %s %d", &students[i].num, students[i].name, &students[i].seat);
    }
    // debug(x);
    bubbleSort(x);
    debug(x);
    checkSeat(x);
    // debug(x);
    qsort(students, x, sizeof(stu), cmp);
    // debug(x);
    for (int i = 0; i < x; i++)
        fprintf(out, "%d %s %d\n", students[i].num, students[i].name, students[i].seat);
    // free(students);
    fclose(in), fclose(out);
    return 0;
}
