// start 17:04
// end 17:38
#include <stdio.h>
#include <stdlib.h>
typedef struct node
{
    int val;
    int depth;
    struct node *left;
    struct node *right;
} node;
node *head;
void createTree(int val)
{
    node *now = head;
    node *pre = head;
    int i = 0;
    while (now != NULL)
    {
        pre = now;
        i++;
        if (val < now->val)
            now = now->left;
        else
            now = now->right;
    }
    now = (node *)calloc(1, sizeof(node));
    now->val = val, now->depth = i + 1;
    if (pre != NULL)
    {
        if (pre->val > val)
            pre->left = now;
        else
            pre->right = now;
    }
    else
        head = now;
}
void searchLeaf(node *cur, node **leaf, int *leafSize)
{
    if (cur->left != NULL)
        searchLeaf(cur->left, leaf, leafSize);
    if (cur->right != NULL)
        searchLeaf(cur->right, leaf, leafSize);
    if (cur->left == NULL && cur->right == NULL)
    {
        leaf[(*leafSize)++] = cur;
        return;
    }
}
int main()
{
    head = NULL;
    int n = 0, x = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &x);
        createTree(x);
    }
    node **leaf = (node **)calloc(n, sizeof(node));
    int size = 0;
    searchLeaf(head, leaf, &size);
    for (int i = 0; i < size; i++)
        printf("%d %d\n", leaf[i]->val, leaf[i]->depth);
    free(leaf);
    return 0;
}