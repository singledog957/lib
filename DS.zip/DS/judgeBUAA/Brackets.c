#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct stack
{
    char val;
    int line;
} stack;
char *skipComment(char *);
char *skipString(char *);
void enter(stack *, char);
int check(stack, char);
int lcnt = 1;
int i;
char record[200];
int r;
int main()
{
    FILE *in = fopen("example.c", "r");
    char s[(int)10e4] = {0};
    int len = fread(s, sizeof(char), (int)10e4, in);
    fclose(in), in = NULL; // Read end
    s[len] = 0;
    char *ps = s;
    // stack *head = (stack *)calloc(201, sizeof(stack));
    stack head[201] = {{0}};
    while (*ps != 0)
    {
        if (*ps == '/' && (*(ps + 1) == '/' || *(ps + 1) == '*'))
            ps = skipComment(ps);
        else if (*ps == '"')
            ps = skipString(ps);
        if (*ps == '{' || *ps == '}' || *ps == '(' || *ps == ')')
        {
            switch (check(head[i], *ps))
            {
            case 1:
                printf("without maching \'%c\' at line %d", *ps, lcnt);
                return 0;
            case 2:
                enter(head, *ps);
                break;
            case 3:
                return 0;
            default:
                break;
            }
        }
        else if (*ps == '\n')
            lcnt++;
        ps++;
    }
    if (i != 0)
    {
        printf("without maching \'%c\' at line %d", head[1].val, head[1].line);
        return 0;
    }
    for (int j = 0; record[j] != 0; j++)
    {
        printf("%c", record[j]);
    }
    return 0;
}
char *skipComment(char *s)
{
    if (*(s + 1) == '/')
    {
        s = strchr(s + 2, '\n');
        lcnt++;
        s++;
        return s;
    }
    else
    {
        s++;
        while (1)
        {
            if (*s == '*' && *(s + 1) == '/')
                break;
            s++;
        }
        s += 2;
        return s;
    }
}
char *skipString(char *s)
{
    s = strchr(s + 1, '"');
    return s + 1;
}
void enter(stack *head, char ps)
{
    head[++i].line = lcnt;
    head[i].val = ps;
    record[r++] = ps;
}
int check(stack head, char ps)
{
    if (ps == '{' && (head.val == '('))
    {
        printf("without maching \'%c\' at line %d", head.val, head.line);
        return 3;
    }
    if (((ps == ')') && (head.val != '(')) || ((ps == '}') && (head.val != '{')))
        return 1;
    else if (((ps == ')') && (head.val == '(')) || ((ps == '}') && (head.val == '{')))
    {
        record[r++] = ps;
        head.val = head.line = 0;
        i--;
        return 0;
    }
    return 2;
}