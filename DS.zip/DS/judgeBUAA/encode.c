#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct node
{
    char letter;
    struct node *next;
    struct node *pre;
} node;
typedef struct code
{
    char origin;
    char passwd;
} code;
char *rm(char *s, int n);
int main()
{
    char s[9999] = {0};
    gets(s);
    int slen = strlen(s);
    int j = 32, m = 0;
    for (int i = slen; j <= 126; i++)
    {
        s[i] = j++;
    }
    char *str = rm(s, strlen(s)); // rm(char* s,int len)
    slen = strlen(str);
    node *head, *l;
    node *tmp = (node *)calloc(1, sizeof(node));
    head = tmp;
    tmp->letter = str[0];
    for (int i = 1; i < slen; i++)
    {
        l = (node *)calloc(1, sizeof(node));
        tmp->next = l, l->pre = tmp;
        tmp = l;
        tmp->letter = str[i];
    }
    l->next = head, head->pre = l;
    code sheet[200] = {{0}};
    int fuck = 0;
    for (m = slen - 1; m > 0; m--)
    {
        sheet[slen - m - 1].origin = head->letter;
        fuck = (int)head->letter % m - 1;
        head->pre->next = head->next, head->next->pre = head->pre;
        node *h = head;
        head = head->next;
        free(h);
        if (fuck == -1)
        {
            head = head->pre;
        }
        for (int i = 0; i < fuck; i++)
        {
            head = head->next;
        }
        sheet[slen - m - 1].passwd = head->letter;
    }
    sheet[slen - 1].origin = head->letter, sheet[slen - 1].passwd = str[0];
    FILE *in = fopen("in.txt", "r");
    FILE *out = fopen("in_crpyt.txt", "w");
    memset(s, 0, 9999 * sizeof(char));
    fread(s, sizeof(char), 9999, in);
    int len = strlen(s);
    j = 0;
    for (int i = 0; i < len; i++)
    {
        j = 0;
        while (s[i] != sheet[j].origin && j < slen)
        {
            j++;
        }
        if (j == slen)
        {
            fputc(s[i], out);
            continue;
        }
        fputc(sheet[j].passwd, out);
    }
    fclose(in), fclose(out);
    in = out = NULL;
    return 0;
}
char *rm(char *s, int n)
{
    char *tmp = s + 1;
    static char k[101] = {0};
    for (int i = 0; i < n; i++)
    {
        if (s[i] == 31)
        {
            tmp++;
            continue;
        }
        char *buf = strchr(tmp, s[i]);
        while (buf != NULL)
        {
            *buf = 31;
            buf = strchr(tmp, s[i]);
        }
        tmp++;
        buf = NULL;
    }
    int j = 0;
    for (int i = 0; s[i] != '\0'; i++)
    {
        if (s[i] == 31)
            continue;
        k[j++] = s[i];
    }
    return k;
}