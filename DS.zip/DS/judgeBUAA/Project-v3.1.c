#pragma GCC optimize("O3")
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXWORDSSIZE 80
#define SAMPLENUM 500
#define ARTICLENUM 16000 // last modified
#define STOPWORDSNUM 20000
#define HASHNUM 10000
#define MAXWORDSNUM 106000
#define MAXWORDSPER 60000
#define TITLELEN 10
#define MAXTITLE 1000
#define hash(a) a - 'a'
FILE *stopword, *sample, *article, *hashvalue, *result, *debug;
typedef struct word
{
    char s[MAXWORDSSIZE];
    int totalTimes;
} word;
typedef struct trie
{
    struct trie *words[26];
    int x;
    word *s;
} trie;
trie *root, *rootFeature;
int istop, isample, iarticle;
char **stopwords, **hash, **featureArticle; //**featureSample,
char **numSample, **numArticle;
char **fingerSample, **fingerArticle;
int **weightSample, **weightArticle;
char ****cmpResult; // cmpResult[isample][hamming][i],char*
word *words;

void fileOpen()
{
    stopword = fopen("stopwords.txt", "r");
    sample = fopen("sample.txt", "r");
    article = fopen("article.txt", "r"); // article.txt
    hashvalue = fopen("hashvalue.txt", "r");
    result = fopen("result.txt", "w");
    // debug = fopen("debug2.txt", "w");
}
void fileClose()
{
    fclose(stopword);
    fclose(sample);
    fclose(article);
    fclose(hashvalue);
    fclose(result);
    // fclose(debug);
}
int cmp(const void *x, const void *y)
{
    if (((word *)x)->totalTimes == ((word *)y)->totalTimes)
        return strcmp(((word *)x)->s, ((word *)y)->s);
    return ((word *)y)->totalTimes - ((word *)x)->totalTimes;
}
char tolower(char x)
{
    if (x >= 'A' && x <= 'Z')
        x ^= ' ';
    return x;
}
void swap(word *a, word *b)
{
    word tmp = *a;
    *a = *b;
    *b = tmp;
}
int partion(int l, int r)
{
    if (l > r)
        return -1;
    int index = l + rand() % (r - l + 1);
    swap(&words[index], &words[l]);
    int pivot = words[l].totalTimes;
    int i = l + 1, j = r;
    while (i < j)
    {
        while ((i <= r && words[i].totalTimes > pivot) || (words[i].totalTimes == pivot && strcmp(words[l].s, words[i].s) > 0))
            i++;
        while ((j >= i && words[j].totalTimes < pivot) || (words[j].totalTimes == pivot && strcmp(words[l].s, words[j].s) < 0))
            j--;
        if (i < j)
            swap(&words[i], &words[j]);
    }
    if (j >= l)
        swap(&words[l], &words[j]);
    return j;
}
void quickSelect(int l, int r, int N)
{
    while (l < r)
    {
        int mid = partion(l, r);
        if (mid < N - 1)
            l = mid + 1;
        else if (mid > N - 1)
            r = mid - 1;
        else
            return;
    }
}
/*char *strcasestr(const char *str1, const char *str2)
{
    char *cp = (char *)str1;
    char *s1, *s2;

    if (!*str2)
        return (char *)str1;

    while (*cp)
    {
        s1 = cp;
        s2 = (char *)str2;

        while (*s1 && *s2 && !(tolower(*s1) - tolower(*s2)))
            s1++, s2++;
        if (!*s2)
            return cp;
        cp++;
    }

    return NULL;
}*/
void getHash(int N, int M)
{
    char tmp[129] = {0};
    for (int i = 0; i < N; i++)
    {
        hash[i] = (char *)calloc(M + 1, sizeof(char));
        fscanf(hashvalue, "%s", tmp);
        for (int j = 0; j < M; j++)
            strncpy(hash[i], tmp, M);
        hash[i][M] = 0;
    }
}
int judgeHash(int row, int col)
{
    if (hash[row][col] == '0')
        return -1;
    else
        return 1;
}
void getStopWords()
{
    char s[MAXWORDSSIZE];
    while (fscanf(stopword, "%s", s) != EOF)
    {
        stopwords[istop] = (char *)calloc(MAXWORDSSIZE, sizeof(char));
        strcpy(stopwords[istop++], s);
    }
}
char *searchStopWords(char *s)
{
    int low = 0, high = istop - 1;
    int mid = istop / 2;
    while (low <= high)
    {
        int res = strcmp(s, stopwords[mid]);
        if (res < 0)
            high = mid - 1;
        else if (res > 0)
            low = mid + 1;
        else
            return stopwords[mid];
        mid = (high + low) / 2;
    }
    return NULL;
    /*for (int i = 0; i < istop; i++)
    {
        if (strcmp(s, stopwords[i]) == 0)
            return stopwords[i];
    }
    return NULL;*/
}
word *searchWords(char *key, word *obj) //  0带插入
{
    trie *now = root;
    int i = 0;
    while (key[i] != 0)
    {
        if (now->words[hash(key[i])] == NULL)
        {
            // insert
            while (key[i] != 0)
            {
                trie *tmp = (trie *)calloc(1, sizeof(trie));
                now->words[hash(key[i++])] = tmp;
                now = tmp;
            }
            now->s = obj;
            return NULL;
        }
        now = now->words[hash(key[i])];
        i++;
    }
    if (now->s == NULL)
    {
        now->s = obj;
        return NULL;
    }
    return now->s;
}
int searchFeature(char *key)
{
    trie *now = rootFeature;
    int i = 0;
    while (key[i] != 0)
    {
        if (now->words[hash(key[i])] == NULL)
            return -1;
        now = now->words[hash(key[i++])];
    }
    // printf("%s %d\n", key, now->x);
    return now->x - 1;
}
void makeFeature(char *key, int x)
{
    trie *now = rootFeature;
    int i = 0;
    while (key[i] != 0)
    {
        if (now->words[hash(key[i])] == NULL)
        {
            // insert
            while (key[i] != 0)
            {
                trie *tmp = (trie *)calloc(1, sizeof(trie));
                now->words[hash(key[i++])] = tmp;
                now = tmp;
            }
            now->x = x + 1;
            return;
        }
        now = now->words[hash(key[i++])];
    }
    now->x = x + 1;
}
void getFeature(int N) // 记录标题
{
    int iwords = 0;
    FILE *webpage = article;
    char **feature = featureArticle;
    char now[MAXWORDSSIZE];
    numArticle[0] = (char *)calloc(TITLELEN, sizeof(char));
    fscanf(webpage, "%s", numArticle[iarticle]);
    while (fscanf(webpage, "%[a-zA-Z]", now) != EOF)
    {
        char c = fgetc(webpage);
        if (c == '\f')
        {
            numArticle[++iarticle] = (char *)calloc(TITLELEN, sizeof(char));
            fscanf(webpage, "%s", numArticle[iarticle]);
            continue;
        }
        if (now == NULL || (now)[0] == 0)
            continue;
        int len = strlen(now);
        if (len >= 20)
            continue;
        (now)[len] = 0;
        for (int i = 0; now[i] != 0; i++)
            (now)[i] = tolower((now)[i]);
        if (searchStopWords(now) == NULL)
        {
            word *tmp = searchWords(now, &words[iwords]);
            if (tmp != NULL)
            {
                tmp->totalTimes++;
            }
            else
            {
                strcpy(words[iwords++].s, now);
            }
        }
        memset(now, 0, sizeof(char) * MAXWORDSSIZE);
    }
    // qsort(words,iwords,sizeof(word),cmp);
    quickSelect(0, iwords - 1, N);
    qsort(words, N, sizeof(word), cmp);
    /*for (int i = 0; i < N; i++)
    {
        fprintf(debug, "%s\n", words[i].s);
    }*/
    for (int i = 0; i < N; i++)
    {
        int len = strlen(words[i].s);
        feature[i] = (char *)calloc(len + 1, sizeof(char));
        strcpy(feature[i], words[i].s);
        makeFeature(words[i].s, i);
    }
    // free(words);
    rewind(sample), rewind(article); // 注意rewind
}
void getWeight(int ctl, int N) // 0 for sample,1 for article,all doc
{
    FILE *webpage = sample;
    int **weight = weightSample;
    int iweb = 0;
    if (ctl)
    {
        webpage = article;
        weight = weightArticle;
    }
    else
    {
        numSample[0] = (char *)calloc(TITLELEN, sizeof(char));
        fscanf(webpage, "%s", numSample[0]);
    }
    char lines[MAXWORDSSIZE];
    // 对每一个feature，在sample中查找
    weight[0] = (int *)calloc(N, sizeof(int));
    while (fscanf(webpage, "%[a-zA-Z]", lines) != EOF)
    {
        char c = fgetc(webpage);
        if (c == '\f')
        {
            if (ctl == 0)
            {
                numSample[++isample] = (char *)calloc(TITLELEN, sizeof(char));
                fscanf(webpage, "%s", numSample[isample]);
                iweb = isample;
            }
            else
                iweb++;
            weight[iweb] = (int *)calloc(N, sizeof(int));
            continue;
        }
        if (lines[0] == 0)
            continue;
        int len = strlen(lines);
        if (len >= 20)
            continue;
        (lines)[len] = 0;
        for (int i = 0; lines[i] != 0; i++)
            lines[i] = tolower(lines[i]);
        int tmp = searchFeature(lines);
        if (tmp != -1)
            weight[iweb][tmp]++;
        lines[0] = 0;
    }
}
void createFinger(int ctl, int N, int M) // all docs，重写到全局
{
    int iweb = isample;
    int **weight = weightSample;
    char **finger = fingerSample; // fingerArticle;
    if (ctl)
    {
        iweb = iarticle;
        weight = weightArticle;
        finger = fingerArticle;
    }
    int sign = 0;
    for (int i = 0; i < iweb; i++)
    {
        finger[i] = (char *)calloc(M + 1, sizeof(char));
        for (int k = 0; k < M; k++)
        {
            for (int j = 0; j < N; j++)
                sign += weight[i][j] * judgeHash(j, k); // weight正确？sign
            finger[i][k] = (sign > 0) ? '1' : '0';
            sign = 0;
        }
    }
}
int getHamming(int sample, int article, int M)
{
    int cnt = M;
    for (int i = 0; i < M; i++)
        cnt -= (fingerArticle[article][i] == fingerSample[sample][i]);
    return cnt;
}
void cmpFinger(int M)
{
    for (int i = 0; i < isample; i++)
    {
        int cnt[4] = {0};
        for (int j = 0; j < iarticle; j++)
        {
            int index = getHamming(i, j, M);
            if (index > 3)
                continue;
            else // cmpResult[isample][hamming][i],char*
                cmpResult[i][index][cnt[index]++] = numArticle[j];
        }
    }
}
void print()
{
    for (int i = 0; i < 4; i++)
    {
        int j = 0;
        if (cmpResult[0][i][0] != NULL)
            printf("%d:", i);
        for (j = 0; cmpResult[0][i][j] != NULL; j++)
            printf("%s ", cmpResult[0][i][j]);
        if (j != 0)
            puts("");
    }
}
void fprint()
{
    for (int i = 0; i < isample; i++) // cmpResult[isample][hamming][i],char*
    {
        fprintf(result, "%s\n", numSample[i]);
        for (int j = 0; j < 4; j++)
        {
            int k = 0;
            if (cmpResult[i][j][0] != NULL)
                fprintf(result, "%d:", j);
            for (k = 0; cmpResult[i][j][k] != NULL; k++)
            {
                fprintf(result, "%s ", cmpResult[i][j][k]);
                // free(cmpResult[i][j][k]);
            }
            if (k != 0)
                fprintf(result, "\n");
            // free
            free(cmpResult[i][j]);
        }
        free(cmpResult[i]);
    }
    free(cmpResult);
}
void charfree(char **p, int n)
{
    for (int i = 0; i < n; i++)
        free(p[i]);
    free(p);
}
void numfree(int **p, int n)
{
    for (int i = 0; i < n; i++)
        free(p[i]);
    free(p);
}
void trieFree(trie *obj)
{
    if (obj == NULL)
        return;
    for (int i = 0; i < 26; i++)
        trieFree(obj->words[i]);
    free(obj);
}
int main(int argc, char *argv[])
{
    fileOpen();
    int N, M;
    N = atoi(argv[1]), M = atoi(argv[2]);
    printf("%d %d", N, M);
    root = (trie *)calloc(1, sizeof(trie));
    stopwords = (char **)calloc(STOPWORDSNUM, sizeof(char *)); // 数量未知,对于stopwords与hash,无需传参
    hash = (char **)calloc(HASHNUM, sizeof(char *));           // 数量未知
    words = (word *)calloc(MAXWORDSNUM, sizeof(word));
    getStopWords();
    getHash(N, M);
    weightSample = (int **)calloc(SAMPLENUM, sizeof(int *));   // 文章篇数未知
    weightArticle = (int **)calloc(ARTICLENUM, sizeof(int *)); // 文章篇数未知
    numSample = (char **)calloc(SAMPLENUM, sizeof(char *));
    numArticle = (char **)calloc(ARTICLENUM, sizeof(char *));
    fingerArticle = (char **)calloc(ARTICLENUM, sizeof(char *));
    fingerSample = (char **)calloc(SAMPLENUM, sizeof(char *));
    featureArticle = (char **)calloc(N, sizeof(char *));
    rootFeature = (trie *)calloc(1, sizeof(trie)); // 初始化结束
    getFeature(N);                                 // debug on
    /*for (int i = 0; i < N; i++)
    {
        featureArticle[i] = (char *)calloc(MAXWORDSSIZE, sizeof(char));
        fscanf(debug, "%s", featureArticle[i]);
        fprintf(debug, "%s\n", featureArticle[i]);
    }*/
    getWeight(0, N);
    getWeight(1, N);
    createFinger(0, N, M);
    createFinger(1, N, M);
    /*for (int i = 0; i < N; i++)
    {
        printf("%d ", weightArticle[0][i]);
    }
    printf("%s", fingerArticle[0]);*/
    cmpResult = (char ****)calloc(isample, sizeof(char ***)); // cmpResult[isample][hamming][i],char*
    for (int i = 0; i < isample; i++)
    {
        cmpResult[i] = (char ***)calloc(4, sizeof(char **));
        for (int j = 0; j < 4; j++)
            cmpResult[i][j] = (char **)calloc(MAXTITLE, sizeof(char *)); // 假设每个汉明值最多100个标题
    }
    cmpFinger(M);
    print();
    fprint();
    charfree(stopwords, STOPWORDSNUM);
    charfree(hash, N);
    charfree(featureArticle, N);
    numfree(weightSample, isample);
    numfree(weightArticle, iarticle);
    charfree(numArticle, iarticle);
    charfree(numSample, isample);
    charfree(fingerArticle, iarticle);
    charfree(fingerSample, isample);
    trieFree(root);
    trieFree(rootFeature);
    fileClose();
    return 0;
}
// 快速选择优化getFeature
// 弃用feature，仅用words
