#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int istr;
char str[100][11] = {0};
double evalRPN(char tokens[][11], int tokensSize)
{
    double *num = (double *)calloc(10000, sizeof(int));
    int pnum = 0;
    for (int i = 0; i < tokensSize; i++)
    {
        char *tmp = tokens[i];
        if (tmp[0] <= '9' && tmp[0] >= '0' || strlen(tmp) > 1)
        {
            num[pnum++] = (double)strtol(tmp, NULL, 10);
        }
        else
        {
            switch (tmp[0])
            {
            case '+':
                num[pnum - 2] = num[pnum - 1] + num[pnum - 2];
                break;
            case '-':
                num[pnum - 2] = num[pnum - 2] - num[pnum - 1];
                break;
            case '*':
                num[pnum - 2] = num[pnum - 1] * num[pnum - 2];
                break;
            case '/':
                num[pnum - 2] = num[pnum - 2] / num[pnum - 1];
                break;
            }
            pnum--;
        }
    }
    double ans = num[pnum - 1];
    free(num);
    return ans;
}
int grade(char x, char y) // 待比较，栈顶
{
    if (((x == '*' || x == '/') && (y == '+' || y == '-'))) // x>y
        return 2;
    // else if (((x == '*' || x == '/') && (y == '*' || y == '/')) || ((x == '+' || x == '-') && (y == '+' || y == '-')))
    // return 1;
    return 1;
}
void trans(char *s)
{
    char *sign = (char *)calloc(1000, sizeof(int));
    int psign = 0, j = 0, npre = 0;
    for (int i = 0; s[i] != 0; i++)
    {
        if (s[i] == ' ' || s[i] == '=')
            continue;
        if (s[i] <= '9' && s[i] >= '0' || s[i] == '-' && npre == 1)
        {
            while (s[i] <= '9' && s[i] >= '0' || s[i] == '-' && npre == 1)
            {
                str[istr][j++] = s[i++];
                npre = 0;
            }
            j = npre = 0;
            i--, istr++;
        }
        else // sign
        {
            if (s[i] != ')')
                npre = 1;
            if (s[i] == '(' || psign == 0)
            {
                sign[psign++] = s[i];
                continue;
            }
            else if (grade(s[i], sign[psign - 1]) == 2)
            {
                sign[psign++] = s[i];
            }
            else if (s[i] == ')') // meet )
            {
                while (sign[psign - 1] != '(')
                {
                    str[istr++][0] = sign[--psign];
                    sign[psign] = 0;
                }
                sign[--psign] = 0;
            }
            else
            {
                if (sign[psign - 1] == '(')
                    sign[psign++] = s[i];
                else
                {
                    str[istr++][0] = sign[--psign];
                    sign[psign++] = s[i];
                }
            }
        }
    }
    while (psign != 0)
    {
        str[istr++][0] = sign[--psign];
    }
    free(sign);
}
/*{
    if (s[i] != '(' && s[i] != ')')
    {
        if (psign == 0) // sign empy, enter
        {
            sign[psign++] = s[i];
            continue;
        }
        while (grade(s[i], sign[psign - 1]) == 2) // higer grade
        {
            sign[psign++] = s[i];
        }

        str[istr++][0] = sign[--psign];
        sign[psign] = 0;
    }
    else // meet brackets
    {
        if (s[i] == '(')
            sign[psign++] = '(';
        else // meet )
        {
            sign[psign] = 0;
            while (sign[psign - 1] != '(')
                str[istr++][0] = sign[--psign];
            sign[--psign] = 0;
        }
    }
}*/

int main()
{
    char s[1000] = {0};
    gets(s);
    // char s[] = "(((1+2)+13/10)+4)* (5-5) =";
    trans(s);
    printf("%.2f", evalRPN(str, istr));
    return 0;
}