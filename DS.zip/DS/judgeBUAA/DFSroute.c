#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
typedef struct node
{
    int val;
    int num[1000]; // 编号
} node;

void enGraph(node **edge, int num, int s, int e)
{
    int i = 0;
    while (edge[s][e].num[i] != 0)
        i++;
    edge[s][e].num[i] = num;
    edge[e][s].num[i] = num;
    edge[s][e].val++;
    edge[e][s].val++;
}
void DFS(node **edge, int node, int nodeSize, bool *visit, int **ans, int *ians, int iroute, int *route)
{
    route[iroute++] = node;
    for (int i = 0; i < nodeSize; i++)
    {
        if (edge[node][i].val != 0 && !visit[i])
        {
            if (i == nodeSize - 1)
            {
                route[iroute++] = i;
                memcpy(ans[(*ians)++], route, sizeof(int) * iroute);
                break;
            }
            visit[i] = 1;
            DFS(edge, i, nodeSize, visit, ans, ians, iroute, route);
            visit[i] = 0;
        }
    }
    return;
}

/*void toNum(int x, char *str, int *istr) // istr 可写入的第一位
{
    char s[10] = {0};
    int is = 0;
    int d;
    while (x)
    {
        d = x % 10;
        x /= 10;
        s[is++] = d;
    }
    is--;
    while (is >= 0)
        str[(*istr)++] = s[is--] + '0';
    // str[(*istr)++] = 0;
}*/
void getAns(int **strAns, int *istrAns, int *str, int istr, node **edge, int **ans, int ians, int ichar, int inum)
{
    int i = 0;
    int start = ans[ians][ichar], end = ans[ians][ichar + 1];
    if (end == 0)
    {
        // str[istr++] = edge[start][end].num[inum] + '0';
        str[istr++] = edge[start][end].num[inum];
        str[istr++] = -1;
        strAns[*istrAns] = calloc(istr, sizeof(int));
        memcpy(strAns[*istrAns], str, sizeof(int) * (istr));
        (*istrAns)++;
        return;
    }
    while (i < edge[start][end].val)
    {
        // toNum(edge[start][end].num[i], str, &istr);
        str[istr++] = edge[start][end].num[i];
        // str[istr++] = ' ';
        getAns(strAns, istrAns, str, istr, edge, ans, ians, ichar + 1, i);
        i++, istr--;
    }
}
int cmp(const void *x, const void *y)
{
    int *e1 = (*(int **)x), *e2 = (*(int **)y);
    int i = 0;
    while (e1[i] != -1 && e2[i] != -1)
    {
        if (e1[i] > e2[i])
            return 1;
        else if (e1[i] < e2[i])
            return -1;
        i++;
    }
    if (e1[i] == -1 && e2[i] == -1)
        return 0;
    else if (e1[i] == -1)
        return -1;
    else
        return 1;
}
int main()
{
    node **edge;
    int n, e;
    scanf("%d %d", &n, &e);
    int **ans = calloc(n * (n - 1) / 2, sizeof(int *));
    for (int i = 0; i < n * (n - 1) / 2; i++)
        ans[i] = calloc(e + 1, sizeof(int));
    edge = calloc(n + 1, sizeof(node *));
    for (int i = 0; i < n; i++)
        edge[i] = calloc(n + 1, sizeof(node));
    for (int i = 0; i < e; i++)
    {
        int num, s, e;
        scanf("%d %d %d", &num, &s, &e);
        enGraph(edge, num, s, e);
    }
    int ians = 0;
    int *route = calloc(e + 1, sizeof(int));
    bool *visit = calloc(n + 1, sizeof(bool));
    visit[0] = 1;
    DFS(edge, 0, n, visit, ans, &ians, 0, route);
    /*for (int i = 0; i < ians; i++)
    {
        int j = 0;
        while (ans[i][j] != n - 1)
            printf("%d ", ans[i][j++]);
        printf("%d\n", ans[i][j]);
    }
    printf("\n");*/
    int **strAns = calloc(100, sizeof(int *));
    int istrAns = 0;
    int *str = calloc(n + 1, sizeof(int));
    for (int i = 0; i < ians; i++)
        getAns(strAns, &istrAns, str, 0, edge, ans, i, 0, 0);
    qsort(strAns, istrAns, sizeof(int *), cmp);
    for (int i = 0; i < istrAns; i++)
    {
        for (int j = 0; strAns[i][j + 1] != -1; j++)
            printf("%d ", strAns[i][j]);
        printf("\n");
        free(strAns[i]);
    }
    for (int i = 0; i < ians; i++)
        free(ans[i]);
    for (int i = 0; i < n; i++)
        free(edge[i]);
    free(strAns);
    free(ans);
    free(edge);
    free(route);
    free(str);
    return 0;
}