#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct stack
{
    int op;
    int loc;
    char str[300];
    struct stack *next;
} stack;
stack *top; // points to empty top
char s[550];
void insert(int, char *);
void del(int, char *);
void enter(int, int, char *);
void undo();
int main()
{
    gets(s);
    int n;
    stack *tmp = (stack *)calloc(1, sizeof(stack));
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d %d %s", &(tmp->op), &(tmp->loc), &(tmp->str));
        stack *t = (stack *)calloc(1, sizeof(stack));
        t->next = tmp, tmp = t;
        top = tmp;
    }
    scanf("%d", &n);
    while (n != -1)
    {
        int loc = 0, ndel = 0;
        char str[100] = {0};
        switch (n)
        {
        case 1:
            scanf("%d %s", &loc, str);
            insert(loc, str);
            break;
        case 2:
            scanf("%d %d", &loc, &ndel);
            strncpy(str, s + loc, ndel);
            del(loc, str);
            break;
        case 3:
            if (top->next == NULL)
                break;
            undo();
            break;
        }
        if (n != 3)
            enter(n, loc, str);
        scanf("%d", &n);
    }
    printf("%s", s);
    return 0;
}
void insert(int loc, char *str)
{
    int len = strlen(str), tmp = strlen(s);
    memcpy(s + loc + len, s + loc, strlen(s + loc) * sizeof(char));
    memcpy(s + loc, str, len * sizeof(char));
    s[tmp + len] = 0;
}
void del(int loc, char *str)
{
    int tmp = strlen(s);
    int strlend = strlen(str), slen = strlen(s + loc);
    memcpy(s + loc, s + loc + strlend, sizeof(char) * (slen - strlend));
    s[tmp - strlend] = 0;
}
void enter(int n, int loc, char *str)
{
    top->loc = loc, top->op = n;
    strcpy(top->str, str);
    stack *new = (stack *)calloc(1, sizeof(stack));
    new->next = top, top = new;
}
void undo()
{
    top = top->next;
    switch (top->op) // 1 for del , 2 for insert
    {
    case 1:
        del(top->loc, top->str);
        break;
    case 2:
        insert(top->loc, top->str);
        break;
    }
}
