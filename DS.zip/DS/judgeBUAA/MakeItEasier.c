
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
typedef struct customers
{
    int No;
    int type;
    int timer;
} customers;
typedef struct window
{
    customers *cus;
    bool occupied;
} window;
typedef struct seq
{
    customers *cus;
    struct seq *next;
} seq;
seq *head, *tail;
int numCnt = 0;
int windows = 3;
int cur;
int timeWait[1000];
window serv[5] = {{0}};
seq *initialSeq();
void enterSeq(customers *, int);
void deSeq(int);
bool isEmpty();
void checkWindow(bool); // check add or remove
void passCircle();      // cus.timer--,check for leave
int checkdeSeq();       // 1,2,3 for Pri. 4,5 for tmp
void toServe(int, customers *);
int main()
{
    int circles;
    int i = 0;
    tail = head = initialSeq();
    int cnum[100] = {0};
    scanf("%d", &circles);
    for (int i = 0; i < circles; i++)
    {
        scanf("%d", &cnum[i]);
    }
    while (i < circles)
    {
        cur += cnum[i];
        checkWindow(1);
        for (int j = 0; j < cnum[i]; j++) // cnum: num of customers per circle
        {
            customers *cus = (customers *)calloc(1, sizeof(cus));
            scanf("%d", &(cus->type));
            cus->No = ++numCnt;
            enterSeq(cus, i + 1);
        }
        while (checkdeSeq() && head->cus)
            toServe(i, head->cus);
        passCircle();
        i++;
    }
    // No more customers
    while (isEmpty() == false)
    {
        checkWindow(0);
        while (checkdeSeq() && head->cus)
            toServe(i, head->cus);
        i++;
        passCircle();
    }
    for (int i = 0; i < numCnt; i++)
    {
        printf("%d : %d\n", i + 1, timeWait[i]);
    }
    return 0;
}
seq *initialSeq()
{
    seq *new = (seq *)calloc(1, sizeof(seq));
    return new;
}
void enterSeq(customers *cus, int circle) // tail points to NULL
{
    seq *new = (seq *)calloc(1, sizeof(seq));
    tail->cus = cus, tail->next = new;
    tail->cus->timer = circle;
    tail = new;
}
void deSeq(int circle) // bug:结构体中指针free
{
    timeWait[head->cus->No - 1] = circle + 1 - head->cus->timer;
    seq *tmp = head;
    head = head->next;
    free(tmp), tmp = NULL;
    cur--;
}
bool isEmpty()
{
    return (head == tail);
}
void checkWindow(bool flag) // check add or remove. (fixed)Bug:一次增加多个窗口
{
    while (cur / windows >= 7 && windows < 5 && flag == 1)
        windows++;
    if (windows > 3 && cur / windows < 7 && flag == 0) // 减少后满足，则撤去
        windows--;
}

int checkdeSeq() // 1,2,3 for Pri. 4,5 for tmp
{
    for (int i = 0; i < windows; i++)
    {
        if (serv[i].occupied == false)
            return i + 1;
    }
    return 0;
}
void passCircle() // cus.type--,check for leave
{
    // free windows
    for (int i = 0; i < windows && serv[i].cus; i++)
    {
        if (serv[i].occupied)
            serv[i].cus->type--;
        if (serv[i].cus->type == 0)
        {
            serv[i].occupied = false;
            serv[i].cus = NULL;
        }
    }
}
void toServe(int i, customers *cus)
{
    int n = checkdeSeq();
    if (n)
    {
        deSeq(i);
        serv[n - 1].occupied = true;
        serv[n - 1].cus = cus;
    }
    /*switch (checkdeSeq())
    {
    case 1:
        deSeq(i);
        serv[0].occupied = true;
        serv[0].cus = cus;
        break;

    case 2:
        deSeq(i);
        serv[1].occupied = true;
        serv[1].cus = cus;
        break;

    case 3:
        deSeq(i);
        serv[2].occupied = true;
        serv[2].cus = cus;
        break;

    case 4:
        deSeq(i);
        serv[3].occupied = true;
        serv[3].cus = cus;
        break;

    case 5:
        deSeq(i);
        serv[4].occupied = true;
        serv[4].cus = cus;
        break;

    default:
        break;
    }*/
}