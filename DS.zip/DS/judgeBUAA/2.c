// start:
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define P 1000003
#define INF 0x7777777f

typedef struct _node
{
    int direct;
    int dist;
} node;

typedef struct stack
{
    /* data */
    node val;
    struct stack *next;
} stack;

stack *initialStack()
{
    stack *top = (stack *)calloc(1, sizeof(stack));
    top->val.direct = INF;
    return top;
}
node *popStack(stack **top) // ��ջ�����س�ջԪ��
{
    stack *cur = *top;
    if (cur->val.direct != INF)
        *top = (*top)->next;
    return &(cur->val);
}
void enterStack(node *key, stack **top) // ��ջ
{
    stack *tmp = (stack *)calloc(1, sizeof(stack));
    (tmp)->next = *top;
    (*top) = tmp;
    memcpy(&((*top)->val), key, sizeof(node));
}
node *queryStack(stack **top) // �õ�ջ��Ԫ��
{
    if ((*top)->val.direct == INF)
    {
        // printf("Anguei!\n");
        return NULL;
    }
    return &((*top)->val);
}

int getOpsite(int key)
{
    switch (key)
    {
    case 1:
        return 2;
    case 2:
        return 1;
    case 3:
        return 4;
    case 4:
        return 3;
    }
    return 0;
}

int main()
{
    stack *top = initialStack();
    int direct = -1, dist;
    int isteps = 0;
    while (direct != 0)
    {
        scanf("%d-%d", &direct, &dist);
        if (direct == 0)
            break;
        isteps++;
        node *res = queryStack(&top);
        if (res != NULL && getOpsite(res->direct) == direct)
        {
            if (res->dist < dist)
            {
                res->direct = direct;
                res->dist = dist - res->dist;
            }
            else
                res->dist = res->dist - dist;
            if (res->dist == 0)
                popStack(&top);
        }
        else
        {
            node *new = calloc(1, sizeof(stack));
            new->direct = direct, new->dist = dist;
            enterStack(new, &top);
        }
    }
    node ans[1000] = {{0}};
    int ians = 1;
    while (queryStack(&top) != NULL)
    {
        node *res = popStack(&top);
        if (res == NULL)
            break;
        if (ans[ians - 1].direct == res->direct)
            ans[ians - 1].dist += res->dist;
        else
            memcpy(&ans[ians++], res, sizeof(node));
    }
    for (int i = 1; i < ians; i++)
        printf("%d-%d ", getOpsite(ans[i].direct), ans[i].dist);
    return 0;
}