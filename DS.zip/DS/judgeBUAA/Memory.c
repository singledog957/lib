#include <stdio.h>
#include <stdlib.h>
typedef struct node
{
    int address;
    int val;
    struct node *next;
    struct node *pre;
} node;
int main()
{
    int n = 0;
    scanf("%d", &n);
    node *head = (node *)calloc(1, sizeof(node));
    node *tmp = (node *)calloc(1, sizeof(node));
    head->next = tmp;
    tmp->pre = head;
    for (int i = 0; i < n; i++)
    {
        node *s = (node *)calloc(1, sizeof(node));
        scanf("%d %d", &(tmp->address), &(tmp->val));
        tmp->next = s;
        s->pre = tmp;
        tmp = s;
    }
    tmp->next = head;
    head->pre = tmp;
    int m = 0;
    node *cur = head;
h:
    while (m != -1)
    {
        scanf("%d", &m);
        if (m == -1)
            break;
        node *min = head;
        node *back = cur;
        do
        {
            if (cur->val > m)
            {
                if (min->address == 0 || cur->val < min->val)
                    min = cur;
            }
            else if (cur->val == m)
            {
                cur->pre->next = cur->next;
                cur->next->pre = cur->pre;
                node *f = cur->next;
                free(cur);
                cur = f;
                n--;
                goto h;
            }
            cur = cur->next;
        } while (cur != back);
        if (min->val > m)
        {
            min->val -= m;
            cur = min;
        }
    }
    for (int i = 0; i < n; i++)
    {
        if (cur->address == 0)
        {
            i--;
            cur = cur->next;
            continue;
        }
        printf("%d %d\n", cur->address, cur->val);
        cur = cur->next;
    }
    return 0;
}
