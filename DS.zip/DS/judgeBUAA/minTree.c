#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#define INF 0x7777777f
typedef struct Edge
{
    int weight;
    int id;
} Edge;
int primMin(Edge **edge, int *ansId, int nodeSize)
{
    int sum = 0;
    int *tree = calloc(nodeSize, sizeof(int));
    int treeSize = 1;
    int min_weight = INF;
    int min_index[2] = {0}; // x,y
    tree[0] = 1;
    while (treeSize < nodeSize)
    {
        for (int i = 0; i < nodeSize; i++)
        {
            if (tree[i] == 0)
                continue;
            for (int j = 0; j < nodeSize; j++)
            {
                if (tree[j] == 0 && edge[i][j].weight != 0 && min_weight > edge[i][j].weight)
                {
                    min_weight = edge[i][j].weight;
                    min_index[0] = i;
                    min_index[1] = j;
                }
            }
        }
        tree[min_index[1]] = 1;
        ansId[treeSize - 1] = edge[min_index[0]][min_index[1]].id;
        sum += edge[min_index[0]][min_index[1]].weight;
        min_weight = INF;
        treeSize++;
    }
    return sum;
}
int cmp(const void *x, const void *y)
{
    return *(int *)x - *(int *)y;
}
int main()
{
    int nodeSize, edgeSize;
    scanf("%d %d", &nodeSize, &edgeSize);
    Edge **edge = calloc(nodeSize, sizeof(Edge *));
    for (int i = 0; i < nodeSize; i++)
        edge[i] = calloc(nodeSize, sizeof(Edge));
    int id, s, e, w;
    for (int i = 0; i < edgeSize; i++)
    {
        scanf("%d %d %d %d", &id, &s, &e, &w);
        edge[s][e].id = id;
        edge[s][e].weight = w;
        edge[e][s].id = id;
        edge[e][s].weight = w;
    }
    int *ansId = calloc(edgeSize, sizeof(int));
    int sum = primMin(edge, ansId, nodeSize);
    printf("%d\n", sum);
    qsort(ansId, nodeSize - 1, sizeof(int), cmp);
    for (int i = 0; i < nodeSize - 1; i++)
        printf("%d ", ansId[i]);
    free(ansId);
    for (int i = 0; i < nodeSize; i++)
        free(edge[i]);
    free(edge);
    return 0;
}