#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct word
{
    char txt[100];
    int freq;
} word;
int cmp(const void *, const void *);
int main()
{
    FILE *in;
    word a[2000] = {0};
    in = fopen("article.txt", "r");
    char s[20000] = {0};
    fread(s, sizeof(char), 19999, in);
    int slen = strlen(s);
    int cnt = 0;
    for (int i = 0; i < slen; i++)
    {
        if (s[i] <= 'Z' && s[i] >= 'A')
            s[i] = s[i] - 'A' + 'a';
        if (s[i] >= 'a' && s[i] <= 'z')
        {
            cnt++;
        }
        else
            s[i] = 0;
    }
    slen = cnt;
    /* char *fuck = s;
     while (*fuck == 0)
         fuck++;*/
    char *tmp = s;
    int j = 0;
    int wcnt = 0;
    for (j = 0; wcnt < slen; j++)
    {
        sscanf(tmp, "%s", a[j].txt);
        tmp += strlen(a[j].txt) + 1;
        wcnt += strlen(a[j].txt);
        while (*tmp == 0 && wcnt < slen)
            tmp++;
    }
    qsort(a, j, sizeof(word), cmp);
    /*int f = 0;
    while (a[f].txt[0] == 0)
        f++;*/
    for (int i = 0; i < j; i++)
    {
        int m = 0;
        while (strcmp(a[i].txt, a[i + 1].txt) == 0)
        {
            a[i].txt[0] = 0;
            i++, m++;
        }
        a[i].freq = m + 1;
    }
    for (int i = 0; i < j; i++)
    {
        if (a[i].txt[0])
            printf("%s %d\n", a[i].txt, a[i].freq);
    }
    fclose(in);
    return 0;
}
int cmp(const void *x, const void *y)
{
    return strcmp(((word *)x)->txt, ((word *)y)->txt);
}