#include <stdio.h>
#include <stdlib.h>
typedef struct node
{
    int val;
    int times;
    struct node *next;
    struct node *pre;
} node;
int cnt;
node *head, *rear;
node *search(int val)
{
    node *cur = head->next;
    while (cur != NULL && cur->val != val)
    {
        cur = cur->next;
        cnt++;
    }
    if (cur != NULL)
        cnt++;
    return (cur == NULL) ? NULL : cur;
}
int main()
{
    int n, x;
    head = (node *)calloc(1, sizeof(node));
    rear = head;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &x);
        node *now = search(x);
        if (now != NULL)
        {
            now->times++;
            if (now->next != NULL)
            {
                now->pre->next = now->next;
                now->next->pre = now->pre;
            }
            else
            {
                now->pre->next = NULL;
            }
            head->next->pre = now;
            now->pre = head, now->next = head->next;
            head->next = now;
        }
        else
        {
            node *new = (node *)calloc(1, sizeof(node));
            rear->next = new, new->pre = rear;
            new->val = x;
            rear = new;
        }
    }
    printf("%d\n", cnt);
    node *cur = head->next;
    int icur = 0;
    while (cur != NULL && icur < 5)
    {
        printf("%d %d\n", cur->val, cur->times + 1);
        cur = cur->next;
        icur++;
    }
    cur = head;
    while (cur != NULL)
    {
        node *tmp = cur;
        cur = cur->next;
        free(tmp);
    }
    return 0;
}
